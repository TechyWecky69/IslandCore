package net.islandcore.plugin.skilltree;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.UUID;

/** Identifies a SkillTree GUI page and, optionally, a read-only target player. */
public final class SkillTreeHolder implements InventoryHolder {
    public enum Page { MAIN, BIOME, ENCHANTING, LOOT, LOOT_ALL }

    private final Page page;
    private final UUID targetUuid;
    private final boolean readOnly;
    private final String category;
    private final int pageIndex;

    public SkillTreeHolder(Page page) {
        this(page, null, false, null, 0);
    }

    public SkillTreeHolder(Page page, UUID targetUuid, boolean readOnly) {
        this(page, targetUuid, readOnly, null, 0);
    }

    public SkillTreeHolder(Page page, UUID targetUuid, boolean readOnly, String category, int pageIndex) {
        this.page = page;
        this.targetUuid = targetUuid;
        this.readOnly = readOnly;
        this.category = category;
        this.pageIndex = pageIndex;
    }

    public Page getPage() { return page; }
    public UUID getTargetUuid() { return targetUuid; }
    public boolean isReadOnly() { return readOnly; }
    public String getCategory() { return category; }
    public int getPageIndex() { return pageIndex; }

    @Override
    public Inventory getInventory() { return null; }
}
