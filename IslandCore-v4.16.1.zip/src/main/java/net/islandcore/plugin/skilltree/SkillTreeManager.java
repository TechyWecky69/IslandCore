package net.islandcore.plugin.skilltree;

import net.islandcore.plugin.util.Symbols;
import net.islandcore.plugin.managers.LevelManager;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.logging.Level;

/**
 * Per-player skill tree state: which nodes are unlocked, which is active,
 * which biome is selected, and the player's token balance.
 * Persisted to data/skilltree.yml.
 */
public class SkillTreeManager {

    private final JavaPlugin plugin;
    private final SkillTree tree;
    private final File file;
    private FileConfiguration config;

    /**
     * Maps node ID → list of node IDs that must be unlocked before it.
     * Loaded from progtree-config.yml under categories.<id>.cost.requirements.
     */
    private final Map<String, List<String>> prerequisites = new HashMap<>();

    // In-memory cache so we don't hit YAML on every loot tick
    private final Map<UUID, Set<String>> unlockedNodes = new HashMap<>();
    private final Map<UUID, Set<String>> unlockedBiomes = new HashMap<>();
    private final Map<UUID, String> activeNode = new HashMap<>();
    private final Map<UUID, String> activeBiome = new HashMap<>();
    private final Map<UUID, Integer> tokens = new HashMap<>();
    // category -> item material -> 0..3 chance upgrades
    private final Map<UUID, Map<String, Integer>> dropUpgrades = new HashMap<>();
    private final ProgressionLootConfig lootConfig;
    private final LevelManager levelManager;

    public SkillTreeManager(JavaPlugin plugin, SkillTree tree, FileConfiguration progressionConfig, LevelManager levelManager) {
        this.plugin = plugin;
        this.tree = tree;
        this.levelManager = levelManager;
        File dataDir = new File(plugin.getDataFolder(), "data");
        dataDir.mkdirs();
        this.file = new File(dataDir, "skilltree.yml");
        this.lootConfig = new ProgressionLootConfig(plugin, tree, progressionConfig);
        loadPrerequisites(progressionConfig);
        load();
    }

    // ─────────────────────────────────────────────────────
    //  Prerequisites
    // ─────────────────────────────────────────────────────

    /**
     * Loads prerequisite lists from progtree-config.yml.
     * Each category declares: categories.<id>.cost.requirements: [nodeA, nodeB, ...]
     */
    private void loadPrerequisites(FileConfiguration progressionConfig) {
        ConfigurationSection categories = progressionConfig.getConfigurationSection("categories");
        if (categories == null) return;
        for (String category : categories.getKeys(false)) {
            List<String> reqs = progressionConfig.getStringList("categories." + category + ".cost.requirements");
            if (reqs.isEmpty()) continue;
            if (tree.getBiomeNode(category) != null && tree.getNode(category) == null) {
                prerequisites.put("biome:" + category, reqs);
            } else {
                prerequisites.put(category, reqs);
            }
        }
    }

    /**
     * Returns the display names of prerequisite nodes the player has NOT yet
     * unlocked for the given node ID. An empty list means all prerequisites
     * are satisfied (or there are none).
     */
    public List<String> getMissingPrerequisites(UUID uuid, String nodeId) {
        List<String> reqs = prerequisites.getOrDefault(nodeId, List.of());
        if (reqs.isEmpty()) return List.of();

        List<String> missing = new ArrayList<>();
        for (String reqId : reqs) {
            if (!isUnlocked(uuid, reqId)) {
                SkillNode reqNode = tree.getNode(reqId);
                String label = reqNode != null
                        ? stripColor(reqNode.getDisplayName())
                        : reqId;
                missing.add(label);
            }
        }
        return missing;
    }

    /** Returns true only when every prerequisite for the given node is unlocked. */
    public boolean prerequisitesMet(UUID uuid, String nodeId) {
        List<String> reqs = prerequisites.getOrDefault(nodeId, List.of());
        for (String reqId : reqs) {
            if (!isUnlocked(uuid, reqId)) return false;
        }
        return true;
    }

    /**
     * Same as getMissingPrerequisites but for biome nodes.
     * Prereqs listed are other biome IDs that must be unlocked first.
     */
    public List<String> getMissingBiomePrerequisites(UUID uuid, String biomeId) {
        List<String> reqs = prerequisites.getOrDefault("biome:" + biomeId, List.of());
        if (reqs.isEmpty()) return List.of();

        List<String> missing = new ArrayList<>();
        for (String reqId : reqs) {
            if (!isBiomeUnlocked(uuid, reqId)) {
                BiomeNode reqNode = tree.getBiomeNode(reqId);
                String label = reqNode != null
                        ? stripColor(reqNode.getDisplayName())
                        : reqId;
                missing.add(label);
            }
        }
        return missing;
    }

    /** Returns true only when every biome prerequisite for the given biome is unlocked. */
    public boolean biomePrerequisitesMet(UUID uuid, String biomeId) {
        List<String> reqs = prerequisites.getOrDefault("biome:" + biomeId, List.of());
        for (String reqId : reqs) {
            if (!isBiomeUnlocked(uuid, reqId)) return false;
        }
        return true;
    }

    private static String stripColor(String s) {
        return s.replaceAll("§[0-9a-fk-or]", "");
    }

    // ─────────────────────────────────────────────────────
    //  Persistence
    // ─────────────────────────────────────────────────────

    private void load() {
        if (!file.exists()) {
            try { file.createNewFile(); } catch (IOException e) {
                plugin.getLogger().log(Level.SEVERE, "Could not create data/skilltree.yml", e);
            }
        }
        config = YamlConfiguration.loadConfiguration(file);

        // Populate in-memory cache from YAML
        if (config.isConfigurationSection("players")) {
            for (String uuidStr : config.getConfigurationSection("players").getKeys(false)) {
                try {
                    UUID uuid = UUID.fromString(uuidStr);
                    String base = "players." + uuidStr + ".";

                    List<String> unlocked = config.getStringList(base + "unlocked");
                    if (unlocked.contains("end")) {
                        unlocked = new ArrayList<>(unlocked);
                        unlocked.remove("end");
                        unlocked.add("end2");
                    }
                    unlockedNodes.put(uuid, new HashSet<>(unlocked));

                    List<String> biomes = config.getStringList(base + "biomes");
                    biomes.removeIf(id -> tree.getBiomeNode(id) == null);
                    if (biomes.isEmpty()) biomes.add("oak");
                    unlockedBiomes.put(uuid, new HashSet<>(biomes));

                    String active = config.getString(base + "active");
                    if (active != null) {
                        // v3.0.1 used a single "end" node; the redesigned tree
                        // splits that branch into End T1 and End T2.
                        if (active.equals("end")) active = "end2";
                        activeNode.put(uuid, active);
                    }

                    String biome = config.getString(base + "activeBiome");
                    if (biome != null && tree.getBiomeNode(biome) != null) {
                        activeBiome.put(uuid, biome);
                    } else {
                        activeBiome.put(uuid, "oak");
                    }

                    tokens.put(uuid, config.getInt(base + "tokens", 0));

                    Map<String, Integer> upgrades = new HashMap<>();
                    ConfigurationSection upgradeSection = config.getConfigurationSection(base + "drop-upgrades");
                    if (upgradeSection != null) {
                        for (String key : upgradeSection.getKeys(false)) {
                            int level = Math.max(0, Math.min(3, upgradeSection.getInt(key, 0)));
                            if (level > 0) upgrades.put(key, level);
                        }
                    }
                    dropUpgrades.put(uuid, upgrades);
                } catch (IllegalArgumentException ignored) {}
            }
        }
    }

    public synchronized void save() {
        for (UUID uuid : unlockedNodes.keySet()) {
            String base = "players." + uuid + ".";
            config.set(base + "unlocked", new ArrayList<>(unlockedNodes.getOrDefault(uuid, Set.of())));
            config.set(base + "biomes", new ArrayList<>(unlockedBiomes.getOrDefault(uuid, Set.of())));
            config.set(base + "active", activeNode.get(uuid));
            config.set(base + "activeBiome", activeBiome.get(uuid));
            config.set(base + "tokens", tokens.getOrDefault(uuid, 0));
            config.set(base + "drop-upgrades", dropUpgrades.getOrDefault(uuid, Map.of()));
        }
        try { config.save(file); } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Could not save data/skilltree.yml", e);
        }
    }

    // ─────────────────────────────────────────────────────
    //  Player initialisation
    // ─────────────────────────────────────────────────────

    /** Call when a new player joins for the first time. Gives them the start node. */
    public void initPlayer(UUID uuid) {
        if (unlockedNodes.containsKey(uuid)) return;
        Set<String> starter = new HashSet<>();
        starter.add("start");
        unlockedNodes.put(uuid, starter);
        unlockedBiomes.put(uuid, new HashSet<>(Set.of("oak")));
        activeNode.put(uuid, "start");
        activeBiome.put(uuid, "oak");
        tokens.put(uuid, 0);
    }

    /** Wipes a player's skill tree progress entirely so initPlayer() starts them over. */
    public synchronized void resetPlayer(UUID uuid) {
        unlockedNodes.remove(uuid);
        unlockedBiomes.remove(uuid);
        activeNode.remove(uuid);
        activeBiome.remove(uuid);
        tokens.remove(uuid);
        dropUpgrades.remove(uuid);
        config.set("players." + uuid, null);
        save();
    }

    // ─────────────────────────────────────────────────────
    //  Token management
    // ─────────────────────────────────────────────────────

    /** Every player UUID that has ever joined (and so has skill tree state). Used by the ratings leaderboard. */
    public Set<UUID> getKnownPlayers() { return Collections.unmodifiableSet(unlockedNodes.keySet()); }

    /** Fraction (0.0-1.0) of skill nodes + biomes this player has unlocked. Used for the automatic island score. */
    public double getProgressFraction(UUID uuid) {
        int totalNodes = tree.getNodes().size();
        int totalBiomes = tree.getBiomeNodes().size();
        if (totalNodes == 0 && totalBiomes == 0) return 0.0;

        double nodeFrac = totalNodes == 0 ? 0.0 : (double) getUnlockedNodes(uuid).size() / totalNodes;
        double biomeFrac = totalBiomes == 0 ? 0.0 : (double) getUnlockedBiomes(uuid).size() / totalBiomes;

        if (totalBiomes == 0) return nodeFrac;
        return (nodeFrac + biomeFrac) / 2.0;
    }

    public int getTokens(UUID uuid) { return tokens.getOrDefault(uuid, 0); }

    public void addTokens(UUID uuid, int amount) {
        tokens.merge(uuid, amount, Integer::sum);
    }

    public boolean spendTokens(UUID uuid, int amount) {
        int current = getTokens(uuid);
        if (current < amount) return false;
        tokens.put(uuid, current - amount);
        return true;
    }

    // ─────────────────────────────────────────────────────
    //  Node state
    // ─────────────────────────────────────────────────────

    public boolean isUnlocked(UUID uuid, String nodeId) {
        return unlockedNodes.getOrDefault(uuid, Set.of()).contains(nodeId);
    }

    public Set<String> getUnlockedNodes(UUID uuid) {
        return Collections.unmodifiableSet(unlockedNodes.getOrDefault(uuid, Set.of()));
    }

    public String getActiveNode(UUID uuid) { return activeNode.get(uuid); }

    public void setActiveNode(UUID uuid, String nodeId) { activeNode.put(uuid, nodeId); }

    /**
     * Attempts to unlock a node. Checks token balance and prerequisites —
     * item costs are checked and consumed by SkillTreeListener before calling
     * this. Returns true on success.
     */
    public boolean unlockNode(UUID uuid, String nodeId) {
        SkillNode node = tree.getNode(nodeId);
        if (node == null) return false;
        if (isUnlocked(uuid, nodeId)) return false;
        if (!prerequisitesMet(uuid, nodeId)) return false;
        if (!spendTokens(uuid, node.getTokenCost())) return false;
        unlockedNodes.computeIfAbsent(uuid, k -> new HashSet<>()).add(nodeId);
        levelManager.addXp(uuid, 200);
        return true;
    }

    // ─────────────────────────────────────────────────────
    //  Biome state
    // ─────────────────────────────────────────────────────

    public boolean isBiomeUnlocked(UUID uuid, String biomeId) {
        return unlockedBiomes.getOrDefault(uuid, Set.of()).contains(biomeId);
    }

    public Set<String> getUnlockedBiomes(UUID uuid) {
        return Collections.unmodifiableSet(unlockedBiomes.getOrDefault(uuid, Set.of()));
    }

    public String getActiveBiome(UUID uuid) { return activeBiome.getOrDefault(uuid, "oak"); }

    public void setActiveBiome(UUID uuid, String biomeId) { activeBiome.put(uuid, biomeId); }

    public boolean unlockBiome(UUID uuid, String biomeId) {
        BiomeNode node = tree.getBiomeNode(biomeId);
        if (node == null) return false;
        if (isBiomeUnlocked(uuid, biomeId)) return false;
        if (!biomePrerequisitesMet(uuid, biomeId)) return false;
        if (!spendTokens(uuid, node.getTokenCost())) return false;
        unlockedBiomes.computeIfAbsent(uuid, k -> new HashSet<>()).add(biomeId);
        levelManager.addXp(uuid, 200);
        return true;
    }

    // ─────────────────────────────────────────────────────
    //  Admin utilities
    // ─────────────────────────────────────────────────────

    /**
     * Unlocks every skill node and every biome for the given player instantly,
     * bypassing token costs, item costs, and prerequisites.
     * Intended for admin/owner use only — the caller is responsible for
     * verifying the player's rank before invoking this.
     */
    public void unlockAll(UUID uuid) {
        Set<String> nodes = unlockedNodes.computeIfAbsent(uuid, k -> new HashSet<>());
        for (String nodeId : tree.getNodes().keySet()) {
            nodes.add(nodeId);
        }

        Set<String> biomes = unlockedBiomes.computeIfAbsent(uuid, k -> new HashSet<>());
        for (String biomeId : tree.getBiomeNodes().keySet()) {
            biomes.add(biomeId);
        }
    }

    // ─────────────────────────────────────────────────────
    //  Loot resolution
    // ─────────────────────────────────────────────────────

    /** Picks a loot item using the progression-tree percentage algorithm. */
    public ItemStack pickLoot(UUID uuid, Random random) {
        String nodeId = activeNode.get(uuid);
        if (nodeId == null) return null;

        SkillNode node = tree.getNode(nodeId);
        if (node == null) return null;

        // Loot membership and rarity come exclusively from progtree-config.yml.
        // For the Biome node, the selected biome id is itself the configured
        // loot category, so there is no generated/registry-backed filtering.
        String category = nodeId.equals("biome")
                ? activeBiome.getOrDefault(uuid, "oak")
                : nodeId;
        List<ProgressionLootConfig.LootItem> pool = new ArrayList<>(lootConfig.getItems(category));

        if (pool.isEmpty()) return null;

        Map<String, Integer> upgrades = dropUpgrades.getOrDefault(uuid, Map.of());
        double totalWeight = 0.0D;
        for (ProgressionLootConfig.LootItem item : pool) {
            int level = upgrades.getOrDefault(category + "." + item.material().name(), 0);
            totalWeight += lootConfig.effectiveWeight(item.rarity(), level);
        }
        if (totalWeight <= 0.0D) return null;

        double roll = random.nextDouble() * totalWeight;
        double cumulative = 0.0D;
        Material chosen = pool.get(pool.size() - 1).material();
        for (ProgressionLootConfig.LootItem item : pool) {
            int level = upgrades.getOrDefault(category + "." + item.material().name(), 0);
            cumulative += lootConfig.effectiveWeight(item.rarity(), level);
            if (roll < cumulative) {
                chosen = item.material();
                break;
            }
        }
        return buildLootItem(chosen, node, random);
    }

    /**
     * Converts the selected material into the actual item awarded to the
     * player. Enchanted books need special handling so they contain a real
     * stored enchantment rather than being blank.
     */
    private ItemStack buildLootItem(Material material, SkillNode node, Random random) {
        if (material == Material.ENCHANTED_BOOK) {
            return createEnchantedBook(node, random);
        }
        return new ItemStack(material, 1);
    }

    /** Builds an enchanted book carrying one real, randomly-picked enchantment. */
    private ItemStack createEnchantedBook(SkillNode node, Random random) {
        ItemStack book = new ItemStack(Material.ENCHANTED_BOOK);
        ItemMeta rawMeta = book.getItemMeta();

        if (!(rawMeta instanceof EnchantmentStorageMeta meta)) {
            return book;
        }

        Enchantment[] all = Enchantment.values();
        if (all.length == 0) {
            return book;
        }

        Enchantment enchant = all[random.nextInt(all.length)];

        int level;
        if (node.getId().equals("enchanting3")) {
            // T3 always gives the enchantment at its maximum level.
            level = enchant.getMaxLevel();
        } else if (node.getId().equals("enchanting2")) {
            // T2 is capped at level 1, while respecting enchantments whose
            // minimum valid level is higher than 1.
            level = Math.max(enchant.getStartLevel(), 1);
        } else {
            // T1 and all other categories receive a random valid level.
            int min = enchant.getStartLevel();
            int max = enchant.getMaxLevel();
            level = min + random.nextInt((max - min) + 1);
        }

        level = Math.max(enchant.getStartLevel(), Math.min(level, enchant.getMaxLevel()));
        meta.addStoredEnchant(enchant, level, true);
        book.setItemMeta(meta);
        return book;
    }

    public int getLevel(UUID uuid) { return levelManager.getLevel(uuid); }

    public ProgressionLootConfig getLootConfig() { return lootConfig; }

    public String getConfiguredLootCategory(UUID uuid, String category) {
        return "biome".equals(category) ? activeBiome.getOrDefault(uuid, "oak") : category;
    }

    private String effectiveLootCategory(UUID uuid, String category) {
        return getConfiguredLootCategory(uuid, category);
    }

    public int getDropUpgrade(UUID uuid, String category, Material material) {
        String effectiveCategory = effectiveLootCategory(uuid, category);
        return dropUpgrades.getOrDefault(uuid, Map.of()).getOrDefault(effectiveCategory + "." + material.name(), 0);
    }

    public boolean canUpgradeDrop(UUID uuid, String category, Material material) {
        String effectiveCategory = effectiveLootCategory(uuid, category);
        ProgressionLootConfig.Rarity rarity = lootConfig.getRarity(effectiveCategory, material);
        if (rarity == ProgressionLootConfig.Rarity.COMMON) return false;
        return getDropUpgrade(uuid, effectiveCategory, material) < 3;
    }

    /** Atomically spends tokens and copies of the upgraded item. */
    public boolean upgradeDrop(UUID uuid, String category, Material material) {
        if (!canUpgradeDrop(uuid, category, material)) return false;
        org.bukkit.entity.Player player = plugin.getServer().getPlayer(uuid);
        if (player == null) return false;

        String effectiveCategory = effectiveLootCategory(uuid, category);
        int nextLevel = getDropUpgrade(uuid, effectiveCategory, material) + 1;
        ProgressionLootConfig.UpgradeCost cost = lootConfig.getUpgradeCost(effectiveCategory, material, nextLevel);
        if (!hasItem(player, cost.itemMaterial(), cost.items())) return false;
        if (!spendTokens(uuid, cost.tokens())) return false;

        removeItems(player, cost.itemMaterial(), cost.items());
        dropUpgrades.computeIfAbsent(uuid, k -> new HashMap<>())
                .put(effectiveCategory + "." + material.name(), nextLevel);
        levelManager.addXp(uuid, 10);
        return true;
    }

    private boolean hasItem(org.bukkit.entity.Player player, Material material, int amount) {
        if (amount <= 0) return true;
        int total = 0;
        for (ItemStack stack : player.getInventory().getStorageContents()) {
            if (stack != null && stack.getType() == material) total += stack.getAmount();
            if (total >= amount) return true;
        }
        return false;
    }

    private void removeItems(org.bukkit.entity.Player player, Material material, int amount) {
        int remaining = amount;
        ItemStack[] contents = player.getInventory().getStorageContents();
        for (int i = 0; i < contents.length && remaining > 0; i++) {
            ItemStack stack = contents[i];
            if (stack == null || stack.getType() != material) continue;
            int remove = Math.min(remaining, stack.getAmount());
            stack.setAmount(stack.getAmount() - remove);
            if (stack.getAmount() <= 0) contents[i] = null;
            remaining -= remove;
        }
        player.getInventory().setStorageContents(contents);
    }

    public ProgressionLootConfig.UpgradeCost getDropUpgradeCost(String category, Material material, int nextLevel) {
        return lootConfig.getUpgradeCost(category, material, nextLevel);
    }

    public ProgressionLootConfig.UpgradeCost getDropUpgradeCost(UUID uuid, String category, Material material, int nextLevel) {
        return lootConfig.getUpgradeCost(effectiveLootCategory(uuid, category), material, nextLevel);
    }

    /**
     * Compatibility overload for older GUI code that only supplies the upgrade level.
     * The item-specific material cost cannot be determined without a category/material,
     * so this returns the global token cost and zero item copies. New code should use
     * getDropUpgradeCost(category, material, nextLevel).
     */
    public ProgressionLootConfig.UpgradeCost getDropUpgradeCost(int nextLevel) {
        int level = Math.max(1, Math.min(3, nextLevel));
        return lootConfig.getUpgradeCost(level);
    }

    public double getDropChance(UUID uuid, String category, Material material) {
        String effectiveCategory = effectiveLootCategory(uuid, category);
        List<ProgressionLootConfig.LootItem> items = new ArrayList<>(lootConfig.getItems(effectiveCategory));
        if (items.isEmpty()) return 0.0D;
        double total = 0.0D;
        for (ProgressionLootConfig.LootItem item : items) {
            int level = getDropUpgrade(uuid, effectiveCategory, item.material());
            total += lootConfig.effectiveWeight(item.rarity(), level);
        }
        for (ProgressionLootConfig.LootItem item : items) {
            if (item.material() == material) {
                int level = getDropUpgrade(uuid, effectiveCategory, material);
                return lootConfig.effectiveWeight(item.rarity(), level) / total * 100.0D;
            }
        }
        return 0.0D;
    }

    // ─────────────────────────────────────────────────────
    //  Chat / nametag symbol
    // ─────────────────────────────────────────────────────

    /**
     * Returns the Unicode symbol for the player's currently-active skill node,
     * surrounded by brackets: e.g. {@code [⛏]}.
     * Falls back to {@code [🌲]} (the generic skill-tree icon) when the
     * player has no active node yet.
     */
    /** Returns the active node's symbol with its bronze/silver/gold tier colour. */
    public String getActiveSymbol(UUID uuid) {
        String nodeId = activeNode.get(uuid);
        if (nodeId != null) {
            SkillNode node = tree.getNode(nodeId);
            if (node != null) return node.getColoredSymbol();
        }
        return Symbols.SKILL_TREE;
    }

    /** Returns the active node's symbol without any colour codes. */
    public String getActiveSymbolPlain(UUID uuid) {
        return stripColor(getActiveSymbol(uuid));
    }

    /** Returns the active node's display name without brackets or colour codes. */
    public String getActiveNodeName(UUID uuid) {
        String nodeId = activeNode.get(uuid);
        if (nodeId == null) return "";
        SkillNode node = tree.getNode(nodeId);
        if (node == null) return "";
        return stripColor(stripNodeBrackets(node.getDisplayName()));
    }

    /** Returns the active node's display name in its bronze/silver/gold tier colour. */
    public String getActiveNodeNameColor(UUID uuid) {
        String nodeId = activeNode.get(uuid);
        if (nodeId == null) return "";
        SkillNode node = tree.getNode(nodeId);
        if (node == null) return "";
        return node.getTierColor() + getActiveNodeName(uuid);
    }

    private String stripNodeBrackets(String name) {
        return name.replaceFirst("^\\s*\\[[^\\]]*\\]\\s*", "").trim();
    }
}
