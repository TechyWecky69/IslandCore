package net.islandcore.plugin.skilltree;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Configuration and runtime probability engine for the Progression Tree.
 *
 * The YAML is intentionally the source of truth for item membership and
 * rarity. Individual item chances are NEVER written to disk. At startup the
 * plugin calculates the chance of every item in memory from the number of
 * common/rare/epic items in its category. Upgrades are then applied to that
 * in-memory calculation.
 */
public final class ProgressionLootConfig {
    public enum Rarity { COMMON, RARE, EPIC }

    public record LootItem(Material material, Rarity rarity) {}
    public record UpgradeCost(int tokens, Material itemMaterial, int items) {}

    private final JavaPlugin plugin;
    private final File file;
    private final FileConfiguration config;

    /** category -> material -> calculated percentage (base, no player upgrades). */
    private final Map<String, Map<Material, Double>> baseChances = new HashMap<>();

    public ProgressionLootConfig(JavaPlugin plugin, SkillTree tree, FileConfiguration config) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "progtree-config.yml");
        this.config = config;
        migrateLegacyFormat();
        rebuildChanceCache();
    }

    /** Compatibility constructor for code outside the main bootstrap. */
    public ProgressionLootConfig(JavaPlugin plugin, SkillTree tree) {
        this(plugin, tree, loadConfig(plugin));
    }

    private static FileConfiguration loadConfig(JavaPlugin plugin) {
        File file = new File(plugin.getDataFolder(), "progtree-config.yml");
        if (!file.exists()) plugin.saveResource("progtree-config.yml", false);
        return YamlConfiguration.loadConfiguration(file);
    }

    private void migrateLegacyFormat() {
        ConfigurationSection categories = config.getConfigurationSection("categories");
        if (categories == null) return;

        boolean changed = false;
        for (String category : new ArrayList<>(categories.getKeys(false))) {
            ConfigurationSection oldItems = config.getConfigurationSection("categories." + category + ".items");
            if (oldItems == null) continue;

            // New format already has rarity lists, so there is nothing to migrate.
            if (oldItems.contains("common") || oldItems.contains("rare") || oldItems.contains("epic")) continue;

            Map<Rarity, List<String>> migrated = new EnumMap<>(Rarity.class);
            for (Rarity rarity : Rarity.values()) migrated.put(rarity, new ArrayList<>());
            for (String materialId : oldItems.getKeys(false)) {
                String rarityRaw = oldItems.getString(materialId + ".rarity", "common");
                Rarity rarity = parseRarity(rarityRaw);
                migrated.get(rarity).add(materialId.toUpperCase(Locale.ROOT));
            }

            Object oldCost = config.get("categories." + category + ".cost");
            config.set("categories." + category, null);
            for (Rarity rarity : Rarity.values()) {
                config.set("categories." + category + ".items." + rarityName(rarity), migrated.get(rarity));
            }
            if (oldCost != null) config.set("categories." + category + ".cost", oldCost);
            changed = true;
        }

        if (changed) plugin.getLogger().info("Migrated progression-tree item rarity format; per-item chances were discarded and will be recalculated in memory.");
    }

    /**
     * Reads a rarity list without losing the map entries used by the new
     * per-item upgrade-cost format. Bukkit's getStringList() silently drops
     * map entries, which previously made the plugin think a customised config
     * was empty and append the defaults on every startup.
     */
    private List<Object> getRawItemList(String path) {
        Object raw = config.get(path);
        if (!(raw instanceof List<?> list)) return new ArrayList<>();
        return new ArrayList<>(list);
    }

    private String itemIdFromEntry(Object entry) {
        if (entry instanceof String text) return text;
        if (entry instanceof Map<?, ?> map && !map.isEmpty()) {
            Object key = map.keySet().iterator().next();
            return key == null ? null : String.valueOf(key);
        }
        return null;
    }

    private Rarity findConfiguredRarity(String category, Material material) {
        for (Rarity rarity : Rarity.values()) {
            for (Object entry : getRawItemList("categories." + category + ".items." + rarityName(rarity))) {
                String id = itemIdFromEntry(entry);
                if (id != null && id.equalsIgnoreCase(material.name())) return rarity;
            }
        }
        return defaultRarity(material);
    }

    public List<LootItem> getItems(String category) {
        List<LootItem> result = new ArrayList<>();
        for (Rarity rarity : Rarity.values()) {
            for (Object entry : getRawItemList("categories." + category + ".items." + rarityName(rarity))) {
                String raw = itemIdFromEntry(entry);
                if (raw == null || raw.isBlank()) continue;
                try {
                    Material material = Material.valueOf(raw.toUpperCase(Locale.ROOT));
                    if (!containsMaterial(result, material)) {
                        result.add(new LootItem(material, rarity));
                    }
                } catch (IllegalArgumentException ignored) {
                    plugin.getLogger().warning("Invalid progression-tree item in " + category + ": " + raw);
                }
            }
        }
        return List.copyOf(result);
    }

    private boolean containsItem(String category, Rarity rarity, String material) {
        return getRawItemList("categories." + category + ".items." + rarityName(rarity)).stream()
                .map(this::itemIdFromEntry)
                .filter(Objects::nonNull)
                .anyMatch(s -> s.equalsIgnoreCase(material));
    }

    private static boolean containsMaterial(List<LootItem> list, Material material) {
        return list.stream().anyMatch(i -> i.material() == material);
    }

    public List<LootItem> sortedItems(String category) {
        List<LootItem> result = new ArrayList<>(getItems(category));
        result.sort(Comparator.comparingInt((LootItem i) -> rarityOrder(i.rarity())).thenComparing(i -> i.material().name()));
        return result;
    }

    /** Recalculates all base chances. This cache is intentionally memory-only. */
    public void rebuildChanceCache() {
        baseChances.clear();
        for (String category : categoryNames()) {
            List<LootItem> items = getItems(category);
            if (items.isEmpty()) continue;
            double totalWeight = 0.0D;
            for (LootItem item : items) totalWeight += rarityWeight(item.rarity());
            if (totalWeight <= 0.0D) continue;

            Map<Material, Double> chances = new HashMap<>();
            for (LootItem item : items) {
                chances.put(item.material(), rarityWeight(item.rarity()) / totalWeight * 100.0D);
            }
            baseChances.put(category, chances);
        }
    }

    /** Base chance for an item before any player's upgrades. */
    public double getBaseChance(String category, Material material) {
        return baseChances.getOrDefault(category, Map.of()).getOrDefault(material, 0.0D);
    }

    public double effectiveWeight(Rarity rarity, int upgradeLevel) {
        double base = rarityWeight(rarity);
        double step = switch (rarity) {
            case COMMON -> 0.0D;
            case RARE -> config.getDouble("rarity-weights.rare-upgrade-step", 24.0D);
            case EPIC -> config.getDouble("rarity-weights.epic-upgrade-step", 6.0D);
        };
        return base + step * Math.max(0, Math.min(3, upgradeLevel));
    }

    private double rarityWeight(Rarity rarity) {
        return switch (rarity) {
            case COMMON -> config.getDouble("rarity-weights.common", 100.0D);
            case RARE -> config.getDouble("rarity-weights.rare", 25.0D);
            case EPIC -> config.getDouble("rarity-weights.epic", 6.0D);
        };
    }

    /**
     * Returns the configured cost for a specific Rare/Epic item upgrade.
     * Tokens come from the global upgrade_tokens map; the material and amount
     * come from the upgraded item's FIRST/SECOND/THIRDUPGRADEITEM map.
     */
    public UpgradeCost getUpgradeCost(String category, Material upgradedMaterial, int nextLevel) {
        int level = Math.max(1, Math.min(3, nextLevel));
        int fallbackTokens = switch (level) { case 1 -> 2; case 2 -> 5; default -> 10; };
        int tokens = config.getInt("upgrade_tokens." + level, fallbackTokens);

        String key = switch (level) {
            case 1 -> "FIRSTUPGRADEITEM";
            case 2 -> "SECONDUPGRADEITEM";
            default -> "THIRDUPGRADEITEM";
        };

        Object entry = findRawItemEntry(category, upgradedMaterial);
        if (entry instanceof Map<?, ?> map) {
            Object upgradeRaw = map.values().stream().findFirst().orElse(null);
            if (upgradeRaw instanceof Map<?, ?> upgrades) {
                Object costRaw = upgrades.get(key);
                if (costRaw instanceof Map<?, ?> materialMap && !materialMap.isEmpty()) {
                    Object materialKey = materialMap.keySet().iterator().next();
                    Object amountRaw = materialMap.get(materialKey);
                    try {
                        Material costMaterial = Material.valueOf(String.valueOf(materialKey).toUpperCase(Locale.ROOT));
                        int amount = Integer.parseInt(String.valueOf(amountRaw));
                        return new UpgradeCost(Math.max(0, tokens), costMaterial, Math.max(0, amount));
                    } catch (IllegalArgumentException ignored) {
                        plugin.getLogger().warning("Invalid " + key + " material for " + upgradedMaterial + " in category " + category);
                    }
                }
            }
        }

        // Safe fallback for old configs: use the upgraded item itself.
        int fallbackItems = switch (level) { case 1 -> 1; case 2 -> 2; default -> 4; };
        return new UpgradeCost(Math.max(0, tokens), upgradedMaterial, fallbackItems);
    }

    /** Compatibility overload for legacy callers. */
    public UpgradeCost getUpgradeCost(int nextLevel) {
        int level = Math.max(1, Math.min(3, nextLevel));
        int tokens = config.getInt("upgrade_tokens." + level, switch (level) { case 1 -> 2; case 2 -> 5; default -> 10; });
        int items = switch (level) { case 1 -> 1; case 2 -> 2; default -> 4; };
        return new UpgradeCost(Math.max(0, tokens), null, items);
    }

    private Object findRawItemEntry(String category, Material material) {
        for (Rarity rarity : Rarity.values()) {
            for (Object entry : getRawItemList("categories." + category + ".items." + rarityName(rarity))) {
                String id = itemIdFromEntry(entry);
                if (id != null && id.equalsIgnoreCase(material.name())) return entry;
            }
        }
        return null;
    }

    public String getDisplayRarity(Rarity rarity) {
        return switch (rarity) {
            case COMMON -> "§aCommon";
            case RARE -> "§9Rare";
            case EPIC -> "§5Epic";
        };
    }

    public Rarity getRarity(String category, Material material) {
        for (LootItem item : getItems(category)) if (item.material() == material) return item.rarity();
        return Rarity.COMMON;
    }

    public Set<String> categoryNames() {
        ConfigurationSection section = config.getConfigurationSection("categories");
        return section == null ? Set.of() : section.getKeys(false);
    }

    public FileConfiguration getConfig() { return config; }
    public File getFile() { return file; }

    public void save() {
        try { config.save(file); }
        catch (IOException e) { plugin.getLogger().warning("Could not save progtree-config.yml: " + e.getMessage()); }
    }

    private static Rarity parseRarity(String raw) {
        try { return Rarity.valueOf(raw.trim().toUpperCase(Locale.ROOT)); }
        catch (IllegalArgumentException ignored) { return Rarity.COMMON; }
    }

    private static String normalizeRarity(String raw) {
        try { return rarityName(Rarity.valueOf(raw.trim().toUpperCase(Locale.ROOT))); }
        catch (IllegalArgumentException ignored) { return "common"; }
    }

    private static String rarityName(Rarity rarity) { return rarity.name().toLowerCase(Locale.ROOT); }

    private static int rarityOrder(Rarity rarity) {
        return switch (rarity) { case COMMON -> 0; case RARE -> 1; case EPIC -> 2; };
    }

    private static Rarity defaultRarity(Material material) {
        String name = material.name();
        if (name.contains("ELYTRA") || name.contains("SHULKER") || name.contains("NETHERITE")
                || name.contains("ANCIENT_DEBRIS") || name.contains("DRAGON") || name.contains("TOTEM")
                || name.contains("NETHER_STAR") || name.contains("HEART_OF_THE_SEA") || name.contains("BEACON")
                || name.contains("CONDUIT") || name.contains("ENCHANTED_GOLDEN_APPLE")) return Rarity.EPIC;
        if (name.contains("DIAMOND") || name.contains("EMERALD") || name.contains("WITHER_SKELETON")
                || name.contains("GHAST") || name.contains("NAUTILUS") || name.contains("SADDLE")
                || name.contains("NAME_TAG") || name.contains("END_CRYSTAL") || name.contains("ENDER_EYE")) return Rarity.RARE;
        return Rarity.COMMON;
    }
}
