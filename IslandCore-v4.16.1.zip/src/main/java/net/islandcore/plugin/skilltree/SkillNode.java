package net.islandcore.plugin.skilltree;

import net.islandcore.plugin.util.Colors;
import net.islandcore.plugin.util.Msg;
import net.islandcore.plugin.util.Symbols;
import org.bukkit.Material;

import java.util.List;

/** One unlockable node in the visual Progression Tree. */
public class SkillNode {

    public enum Rarity { COMMON, UNCOMMON, RARE }

    private final String id;
    private final String displayName;
    private final Material icon;
    private final String[] description;
    private final String category;
    private final int tokenCost;
    private final List<ItemCost> itemCosts;
    private final int guiSlot;

    public SkillNode(String id, String displayName, Material icon, String[] description,
                     String category, int tokenCost, List<ItemCost> itemCosts, int guiSlot) {
        this.id = id;
        this.displayName = displayName;
        this.icon = icon;
        this.description = description;
        this.category = category;
        this.tokenCost = tokenCost;
        this.itemCosts = itemCosts;
        this.guiSlot = guiSlot;
    }

    public String getId() { return id; }
    public String getDisplayName() { return displayName; }
    public Material getIcon() { return icon; }
    public String[] getDescription() { return description; }
    public String getCategory() { return category; }
    public int getTokenCost() { return tokenCost; }
    public List<ItemCost> getItemCosts() { return itemCosts; }
    public int getGuiSlot() { return guiSlot; }

    /** Returns the active node's bronze/silver/gold tier colour, or bronze for non-tiered nodes. */
    public String getTierColor() {
        String id = this.id;
        if (id.startsWith("mining1") || id.startsWith("farming1") || id.startsWith("enchanting1")) return Colors.BRONZE;
        if (id.startsWith("mining2") || id.startsWith("farming2") || id.equals("nether1")
                || id.equals("end1") || id.startsWith("enchanting2")
                || id.equals("flowers1")) return Colors.SILVER;
        if (id.startsWith("mining3") || id.startsWith("farming3") || id.equals("nether2")
                || id.equals("end2") || id.startsWith("enchanting3")
                || id.equals("brewing") || id.equals("fishing") || id.equals("biome")
                || id.equals("colour") || id.equals("flowers2")) return Colors.GOLD;
        return Colors.BRONZE;
    }

    /** Returns the node symbol without colour codes. */
    public String getSymbol() {
        String id = this.id;
        if (id.startsWith("mining")) return Symbols.MINING;
        if (id.startsWith("farming")) return Symbols.FARM;
        if (id.startsWith("nether")) return Symbols.NETHER;
        if (id.startsWith("end")) return Symbols.END;
        if (id.startsWith("enchanting")) return Symbols.ENCHANTING;
        if (id.equals("brewing")) return Symbols.ALCHEMY;
        if (id.equals("fishing")) return Symbols.FISHING;
        if (id.equals("biome")) return Symbols.BIOME;
        if (id.equals("colour")) return Symbols.COLOUR;
        if (id.startsWith("flowers")) return Symbols.FLOWER;
        return Symbols.SKILL_TREE;
    }

    public String getColoredSymbol() {
        String symbol = getSymbol();
        String extra = (id.equals("colour") || id.startsWith("flowers")) ? Msg.color("&l") : "";
        return getTierColor() + extra + symbol;
    }

    public static class LootEntry {
        private final Material material;
        private final Rarity rarity;
        public LootEntry(Material material, Rarity rarity) { this.material = material; this.rarity = rarity; }
        public Material getMaterial() { return material; }
        public Rarity getRarity() { return rarity; }
        public int getWeight() {
            return switch (rarity) { case COMMON -> 60; case UNCOMMON -> 30; case RARE -> 10; };
        }
    }

    public static class ItemCost {
        private final Material material;
        private final int amount;
        public ItemCost(Material material, int amount) { this.material = material; this.amount = amount; }
        public Material getMaterial() { return material; }
        public int getAmount() { return amount; }
    }
}
