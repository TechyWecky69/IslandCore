package net.islandcore.plugin.skilltree;

import net.islandcore.plugin.ranks.Rank;
import net.islandcore.plugin.ranks.RankManager;
import net.islandcore.plugin.util.Msg;
import net.islandcore.plugin.util.Symbols;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class SkillTreeGUI {

    public static final String TREE_TITLE = Msg.color("&7[&a" + Symbols.SKILL_TREE + "&7] &fProgression Tree");
    public static final String BIOME_TITLE = Msg.color("&7[&e" + Symbols.BIOME + "&7] &fBiomes");
    public static final String ENCHANT_TITLE = Msg.color("&7[&5" + Symbols.ENCHANTING + "&7] &fEnchanting");

    private static boolean isEnchantNode(String id) {
        return id.equals("brewing") || id.startsWith("enchanting");
    }

    private final SkillTree tree;
    private final SkillTreeManager manager;
    private final RankManager rankManager;

    public SkillTreeGUI(SkillTree tree, SkillTreeManager manager, RankManager rankManager) {
        this.tree = tree;
        this.manager = manager;
        this.rankManager = rankManager;
    }

    /** Returns true if the player holds Admin or Owner rank. */
    private boolean isAdminOrOwner(Player player) {
        Rank rank = rankManager.getRankOrDefault(player.getUniqueId());
        return rank == Rank.ADMIN || rank == Rank.OWNER;
    }

    // ─────────────────────────────────────────────────────
    //  Page: MAIN TREE
    // ─────────────────────────────────────────────────────

    public void openTreeTab(Player player) {
        openTreeTab(player, player.getUniqueId(), false);
    }

    public void openTreeTab(Player player, UUID targetUuid, boolean readOnly) {

        Inventory inv = Bukkit.createInventory(
                new SkillTreeHolder(SkillTreeHolder.Page.MAIN, targetUuid, readOnly),
                SkillTreeSlots.MAIN_SIZE,
                readOnly
                        ? Msg.color("&7[&a" + Symbols.SKILL_TREE + "&7] &f" + targetName(targetUuid) + "'s Progression Tree")
                        : TREE_TITLE
        );

        UUID uuid = targetUuid;

        inv.setItem(
                SkillTreeSlots.MAIN_BACK,
                button(
                        SkillTreeSlots.MAIN_BACK_ICON,
                        "§fBack",
                        "§7Close the skill tree"
                )
        );

        inv.setItem(
                SkillTreeSlots.MAIN_TOKENS,
                buildTokenItem(uuid)
        );

        // Biome button stays locked until the BIOME category itself is unlocked.
        if (readOnly || manager.isUnlocked(uuid, "biome")) {
            inv.setItem(
                    SkillTreeSlots.MAIN_BIOME_BUTTON,
                    button(
                            SkillTreeSlots.MAIN_BIOME_BUTTON_ICON,
                            "§aBiome",
                            "§7Open the biome tab"
                    )
            );
        } else {
            inv.setItem(
                    SkillTreeSlots.MAIN_BIOME_BUTTON,
                    button(
                            Material.BEDROCK,
                            "§c§lBiome Locked",
                            "§7Unlock the §eBiome §7category first.",
                            "§8The biome selector will become available afterwards."
                    )
            );
        }

        // Enchanting button — not currently active tab, no glow
        inv.setItem(
                SkillTreeSlots.MAIN_ENCHANTING_BUTTON,
                button(
                        SkillTreeSlots.MAIN_ENCHANTING_ICON,
                        "§dEnchanting",
                        "§7Open enchanting and brewing"
                )
        );

        // Admin/Owner unlock-all button — only shown to qualifying ranks and
        // only when the slot has been set to a valid position (>= 0).
        if (!readOnly && isAdminOrOwner(player) && SkillTreeSlots.MAIN_ADMIN_UNLOCK >= 0) {
            inv.setItem(
                    SkillTreeSlots.MAIN_ADMIN_UNLOCK,
                    buildAdminUnlockButton()
            );
        }

        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = filler.getItemMeta();

        if (meta != null) {
            meta.setDisplayName(" ");
            filler.setItemMeta(meta);
        }

        for (int slot = 0; slot < inv.getSize(); slot++) {
            if (inv.getItem(slot) == null) {
                inv.setItem(slot, filler);
            }
        }

        for (SkillNode node : tree.getNodes().values()) {

            if (isEnchantNode(node.getId())) {
                continue;
            }

            if (node.getGuiSlot() < 0 || node.getGuiSlot() >= inv.getSize()) {
                continue;
            }

            inv.setItem(
                    node.getGuiSlot(),
                    buildNodeItem(node, uuid)
            );
        }

        player.openInventory(inv);
    }

    // ─────────────────────────────────────────────────────
    //  Page: ENCHANTING
    // ─────────────────────────────────────────────────────

    public void openEnchantTab(Player player) {
        openEnchantTab(player, player.getUniqueId(), false);
    }

    public void openEnchantTab(Player player, UUID targetUuid, boolean readOnly) {

        Inventory inv = Bukkit.createInventory(
                new SkillTreeHolder(SkillTreeHolder.Page.ENCHANTING, targetUuid, readOnly),
                SkillTreeSlots.ENCHANTING_SIZE,
                readOnly
                        ? Msg.color("&7[&5" + Symbols.ENCHANTING + "&7] &f" + targetName(targetUuid) + "'s Enchanting")
                        : ENCHANT_TITLE
        );

        UUID uuid = targetUuid;

        inv.setItem(
                SkillTreeSlots.ENCHANT_TOKENS,
                buildTokenItem(uuid)
        );

        // Back button — returns to MAIN, no glow needed
        inv.setItem(
                SkillTreeSlots.ENCHANT_BACK,
                button(
                        Material.CHEST,
                        "§fBack",
                        "§7Return to the Progression Tree"
                )
        );

        // Current-tab indicator with enchant glow
        inv.setItem(
                SkillTreeSlots.ENCHANT_TAB_INDICATOR,
                tabIndicator(
                        SkillTreeSlots.MAIN_ENCHANTING_ICON,
                        "§d§lEnchanting",
                        "§7Currently viewing enchanting & brewing"
                )
        );

        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = filler.getItemMeta();

        if (meta != null) {
            meta.setDisplayName(" ");
            filler.setItemMeta(meta);
        }

        for (int slot = 0; slot < inv.getSize(); slot++) {
            if (inv.getItem(slot) == null) {
                inv.setItem(slot, filler);
            }
        }

        for (SkillNode node : tree.getNodes().values()) {

            if (!isEnchantNode(node.getId())) {
                continue;
            }

            if (node.getGuiSlot() < 0 || node.getGuiSlot() >= inv.getSize()) {
                continue;
            }

            inv.setItem(
                    node.getGuiSlot(),
                    buildNodeItem(node, uuid)
            );
        }

        player.openInventory(inv);
    }

    // ─────────────────────────────────────────────────────
    //  Page: BIOME
    // ─────────────────────────────────────────────────────

    public void openBiomeTab(Player player) {
        openBiomeTab(player, player.getUniqueId(), false);
    }

    public void openBiomeTab(Player player, UUID targetUuid, boolean readOnly) {

        Inventory inv = Bukkit.createInventory(
                new SkillTreeHolder(SkillTreeHolder.Page.BIOME, targetUuid, readOnly),
                SkillTreeSlots.BIOME_SIZE,
                readOnly
                        ? Msg.color("&7[&e" + Symbols.BIOME + "&7] &f" + targetName(targetUuid) + "'s Biomes")
                        : BIOME_TITLE
        );

        UUID uuid = targetUuid;

        inv.setItem(
                SkillTreeSlots.BIOME_BACK,
                button(
                        Material.CHEST,
                        "§fBack",
                        "§7Return to the Progression Tree"
                )
        );

        inv.setItem(
                SkillTreeSlots.BIOME_TOKENS,
                buildTokenItem(uuid)
        );

        // Current-tab indicator
        inv.setItem(
                SkillTreeSlots.BIOME_CURRENT,
                tabIndicator(
                        Material.OAK_SAPLING,
                        "§a§lBiome",
                        "§7Currently viewing biomes"
                )
        );

        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = filler.getItemMeta();

        if (meta != null) {
            meta.setDisplayName(" ");
            filler.setItemMeta(meta);
        }

        for (int slot = 0; slot < inv.getSize(); slot++) {
            if (inv.getItem(slot) == null) {
                inv.setItem(slot, filler);
            }
        }

        for (BiomeNode node : tree.getBiomeNodes().values()) {

            if (node.getGuiSlot() < 0 || node.getGuiSlot() >= inv.getSize()) {
                continue;
            }

            inv.setItem(
                    node.getGuiSlot(),
                    buildBiomeItem(node, uuid)
            );
        }

        player.openInventory(inv);
    }

    // ─────────────────────────────────────────────────────
    //  Progression loot pages
    // ─────────────────────────────────────────────────────

    public void openLootCategory(Player player, UUID targetUuid, String category, boolean readOnly) {
        openLootCategory(player, targetUuid, category, 0, readOnly);
    }

    public void openLootCategory(Player player, UUID targetUuid, String category, int pageIndex, boolean readOnly) {
        String effectiveCategory = manager.getConfiguredLootCategory(targetUuid, category);
        List<ProgressionLootConfig.LootItem> rareItems = new ArrayList<>();
        for (ProgressionLootConfig.LootItem item : manager.getLootConfig().sortedItems(effectiveCategory)) {
            if (item.rarity() != ProgressionLootConfig.Rarity.COMMON) rareItems.add(item);
        }
        int perPage = 28;
        int maxPage = Math.max(0, (rareItems.size() - 1) / perPage);
        pageIndex = Math.max(0, Math.min(pageIndex, maxPage));

        Inventory inv = Bukkit.createInventory(
                new SkillTreeHolder(SkillTreeHolder.Page.LOOT, targetUuid, readOnly, category, pageIndex),
                SkillTreeSlots.LOOT_SIZE,
                Msg.color("&7[&d" + Symbols.SKILL_TREE + "&7] &f" + prettyCategory(category) + " Drops")
        );

        inv.setItem(SkillTreeSlots.LOOT_BACK, button(Material.CHEST, "§fBack", "§7Return to the Progression Tree"));
        inv.setItem(SkillTreeSlots.LOOT_TITLE, button(Material.CHEST, "§d§l" + prettyCategory(category),
                "§7Rare and Epic items in this category", "§7Click an item to upgrade its chance."));
        inv.setItem(SkillTreeSlots.LOOT_ALL_ITEMS, button(Material.BOOK, "§e§lShow All Items", "§7View every item and its current chance."));
        if (pageIndex > 0) inv.setItem(SkillTreeSlots.LOOT_PREVIOUS, button(Material.ARROW, "§fPrevious", "§7Page " + pageIndex));
        if (pageIndex < maxPage) inv.setItem(SkillTreeSlots.LOOT_NEXT, button(Material.ARROW, "§fNext", "§7Page " + (pageIndex + 2)));

        int start = pageIndex * perPage;
        for (int i = 0; i < perPage && start + i < rareItems.size(); i++) {
            int slot = lootMenuSlot(i);
            inv.setItem(slot, buildLootItem(rareItems.get(start + i), targetUuid, category, readOnly));
        }
        fillEmpty(inv);
        player.openInventory(inv);
    }

    public void openAllLootItems(Player player, UUID targetUuid, String category, int pageIndex, boolean readOnly) {
        String effectiveCategory = manager.getConfiguredLootCategory(targetUuid, category);
        List<ProgressionLootConfig.LootItem> items = manager.getLootConfig().sortedItems(effectiveCategory);
        int perPage = 36;
        int maxPage = Math.max(0, (items.size() - 1) / perPage);
        pageIndex = Math.max(0, Math.min(pageIndex, maxPage));

        Inventory inv = Bukkit.createInventory(
                new SkillTreeHolder(SkillTreeHolder.Page.LOOT_ALL, targetUuid, readOnly, category, pageIndex),
                SkillTreeSlots.LOOT_SIZE,
                Msg.color("&7[&d" + Symbols.SKILL_TREE + "&7] &fAll " + prettyCategory(category) + " Items")
        );
        inv.setItem(SkillTreeSlots.ALL_LOOT_BACK, button(Material.CHEST, "§fBack", "§7Return to rare/epic items"));
        if (pageIndex > 0) inv.setItem(SkillTreeSlots.ALL_LOOT_PREVIOUS, button(Material.ARROW, "§fPrevious", "§7Page " + pageIndex));
        if (pageIndex < maxPage) inv.setItem(SkillTreeSlots.ALL_LOOT_NEXT, button(Material.ARROW, "§fNext", "§7Page " + (pageIndex + 2)));

        int start = pageIndex * perPage;
        for (int i = 0; i < perPage && start + i < items.size(); i++) {
            inv.setItem(9 + i, buildAllLootItem(items.get(start + i), targetUuid, category));
        }
        fillEmpty(inv);
        player.openInventory(inv);
    }

    public ProgressionLootConfig.LootItem getLootMenuItem(String category, UUID targetUuid, int pageIndex, int slot) {
        String effectiveCategory = manager.getConfiguredLootCategory(targetUuid, category);
        List<ProgressionLootConfig.LootItem> items = new ArrayList<>();
        for (ProgressionLootConfig.LootItem item : manager.getLootConfig().sortedItems(effectiveCategory)) {
            if (item.rarity() != ProgressionLootConfig.Rarity.COMMON) items.add(item);
        }
        int index = lootMenuIndex(slot);
        if (index < 0) return null;
        int absolute = pageIndex * 28 + index;
        return absolute >= 0 && absolute < items.size() ? items.get(absolute) : null;
    }

    private ItemStack buildLootItem(ProgressionLootConfig.LootItem loot, UUID uuid, String category, boolean readOnly) {
        ItemStack item = new ItemStack(loot.material());
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        int level = manager.getDropUpgrade(uuid, category, loot.material());
        double chance = manager.getDropChance(uuid, category, loot.material());
        List<String> lore = new ArrayList<>();
        lore.add(manager.getLootConfig().getDisplayRarity(loot.rarity()));
        lore.add(String.format("§7Chance: §f%.4f%%", chance));
        lore.add("§7Upgrade: §f" + level + "/3");
        lore.add(" ");
        if (!readOnly && level < 3) {
            ProgressionLootConfig.UpgradeCost cost = manager.getDropUpgradeCost(uuid, category, loot.material(), level + 1);
            lore.add("§eClick to upgrade");
            lore.add("§7Cost: §6" + cost.tokens() + " tokens §7+ §f" + cost.items() + "x " + prettyName(cost.itemMaterial()));
        } else if (level >= 3) lore.add("§a§lMAX UPGRADE");
        else lore.add("§7Read-only view");
        meta.setDisplayName("§f" + prettyName(loot.material()));
        meta.setLore(lore);
        if (level > 0) applyGlow(meta);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack buildAllLootItem(ProgressionLootConfig.LootItem loot, UUID uuid, String category) {
        ItemStack item = new ItemStack(loot.material());
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.setDisplayName("§f" + prettyName(loot.material()));
        meta.setLore(List.of(
                manager.getLootConfig().getDisplayRarity(loot.rarity()),
                String.format("§7Chance: §f%.4f%%", manager.getDropChance(uuid, category, loot.material())),
                "§7Upgrade: §f" + manager.getDropUpgrade(uuid, category, loot.material()) + "/3"
        ));
        item.setItemMeta(meta);
        return item;
    }

    private static int lootMenuSlot(int index) {
        int row = index / 7;
        int col = index % 7;
        return 10 + row * 9 + col;
    }

    private static int lootMenuIndex(int slot) {
        for (int i = 0; i < 28; i++) if (lootMenuSlot(i) == slot) return i;
        return -1;
    }

    private static String prettyCategory(String category) {
        return switch (category) {
            case "mining1", "mining2", "mining3" -> "Mining";
            case "farming1", "farming2", "farming3" -> "Farming";
            case "enchanting1", "enchanting2", "enchanting3" -> "Enchanting";
            case "brewing" -> "Alchemy";
            case "end1", "end2" -> "End";
            case "nether1", "nether2" -> "Nether";
            case "flowers1", "flowers2" -> "Flowers";
            case "fishing" -> "Fishing";
            case "biome" -> "Biome";
            case "colour" -> "Colour";
            default -> category;
        };
    }

    private static void fillEmpty(Inventory inv) {
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = filler.getItemMeta();
        if (meta != null) { meta.setDisplayName(" "); filler.setItemMeta(meta); }
        for (int slot = 0; slot < inv.getSize(); slot++) if (inv.getItem(slot) == null) inv.setItem(slot, filler);
    }

    private String targetName(UUID uuid) {
        Player target = Bukkit.getPlayer(uuid);
        return target != null ? target.getName() : uuid.toString().substring(0, 8);
    }

    private static String stripNodeBrackets(String name) {
        return name.replaceFirst("^\\s*\\[[^\\]]*\\]\\s*", "").trim();
    }

    // ─────────────────────────────────────────────────────
    //  Item builders
    // ─────────────────────────────────────────────────────

    private ItemStack buildNodeItem(SkillNode node, UUID uuid) {

        boolean unlocked = manager.isUnlocked(uuid, node.getId());
        boolean active = node.getId().equals(manager.getActiveNode(uuid));

        // Check prerequisite satisfaction for lore display
        List<String> missingPrereqs =
                manager.getMissingPrerequisites(uuid, node.getId());

        ItemStack item = new ItemStack(
                active ? Material.EXPERIENCE_BOTTLE : (unlocked ? node.getIcon() : Material.BEDROCK)
        );

        ItemMeta meta = item.getItemMeta();

        if (meta == null) {
            return item;
        }

        if (active) {

            String nodeName = stripNodeBrackets(stripColor(node.getDisplayName()));
            meta.setDisplayName(
                    "§a§lLevel " + manager.getLevel(uuid) + " §7- §f" + nodeName
            );

        } else if (unlocked) {

            meta.setDisplayName(node.getDisplayName());

        } else {

            meta.setDisplayName(
                    "§7§l" + stripColor(node.getDisplayName())
            );
        }

        List<String> lore = new ArrayList<>();

        for (String line : node.getDescription()) {
            lore.add(line);
        }

        lore.add(" ");

        if (active) {

            lore.add("§a§lACTIVE");
            lore.add("§7Your level: §a" + manager.getLevel(uuid));
            lore.add("§dRight-click to view drops");

        } else if (unlocked) {

            lore.add("§eClick to select");
            lore.add("§dRight-click to view drops");

        } else {

            // Show prerequisite requirements before cost info
            if (!missingPrereqs.isEmpty()) {

                lore.add("§c§lREQUIRES:");

                for (String prereq : missingPrereqs) {
                    lore.add("§7• §c" + prereq);
                }

                lore.add(" ");
            }

            lore.add("§c§lLOCKED");

            if (node.getTokenCost() > 0) {

                lore.add(
                        "§7Tokens: §6" + node.getTokenCost()
                );
            }

            for (SkillNode.ItemCost cost : node.getItemCosts()) {

                lore.add(
                        "§7• §f"
                                + cost.getAmount()
                                + "x "
                                + prettyName(cost.getMaterial())
                );
            }

            if (missingPrereqs.isEmpty()) {
                lore.add("§eClick to unlock");
            } else {
                lore.add("§7Unlock prerequisites first");
            }
        }

        meta.setLore(lore);

        meta.addItemFlags(
                ItemFlag.HIDE_ENCHANTS,
                ItemFlag.HIDE_ATTRIBUTES
        );

        // Active category icon gets the enchanted glow
        if (active) {
            applyGlow(meta);
        }

        item.setItemMeta(meta);

        return item;
    }

    private ItemStack buildBiomeItem(
            BiomeNode node,
            UUID uuid
    ) {

        boolean unlocked =
                manager.isBiomeUnlocked(
                        uuid,
                        node.getId()
                );

        boolean active =
                node.getId().equals(
                        manager.getActiveBiome(uuid)
                );

        List<String> missingBiomePrereqs =
                unlocked
                        ? List.of()
                        : manager.getMissingBiomePrerequisites(
                        uuid,
                        node.getId()
                );

        ItemStack item = new ItemStack(
                unlocked ? node.getIcon() : Material.BEDROCK
        );

        ItemMeta meta = item.getItemMeta();

        if (meta == null) {
            return item;
        }

        if (active) {

            meta.setDisplayName(
                    "§a§l" + stripColor(node.getDisplayName())
            );

        } else if (unlocked) {

            meta.setDisplayName(node.getDisplayName());

        } else {

            meta.setDisplayName(
                    "§7§l" + stripColor(node.getDisplayName())
            );
        }

        List<String> lore = new ArrayList<>();

        lore.add(
                "§7"
                        + (
                        node.getBiomeType() ==
                                BiomeNode.BiomeType.FOREST
                                ? "Forest"
                                : "Nether"
                )
                        + " biome"
        );

        lore.add(
                "§7Wood/building family changes with selection."
        );

        lore.add(" ");

        if (active) {

            lore.add("§a§lSELECTED");

        } else if (unlocked) {

            lore.add("§eClick to select");

        } else {

            // Show biome prerequisite requirements before cost info
            if (!missingBiomePrereqs.isEmpty()) {

                lore.add("§c§lREQUIRES:");

                for (String prereq : missingBiomePrereqs) {
                    lore.add("§7• §c" + prereq);
                }

                lore.add(" ");
            }

            lore.add("§c§lLOCKED");

            if (node.getTokenCost() > 0) {

                lore.add(
                        "§7Tokens: §6"
                                + node.getTokenCost()
                );
            }

            for (SkillNode.ItemCost cost :
                    node.getItemCosts()) {

                lore.add(
                        "§7• §f"
                                + cost.getAmount()
                                + "x "
                                + prettyName(
                                cost.getMaterial()
                        )
                );
            }

            if (missingBiomePrereqs.isEmpty()) {
                lore.add("§eClick to unlock");
            } else {
                lore.add("§7Unlock prerequisites first");
            }
        }

        meta.setLore(lore);

        meta.addItemFlags(
                ItemFlag.HIDE_ENCHANTS,
                ItemFlag.HIDE_ATTRIBUTES
        );

        // Active/selected biome icon gets the enchanted glow
        if (active) {
            applyGlow(meta);
        }

        item.setItemMeta(meta);

        return item;
    }

    private ItemStack buildTokenItem(UUID uuid) {

        ItemStack item =
                new ItemStack(SkillTreeSlots.MAIN_TOKENS_ICON);

        ItemMeta meta =
                item.getItemMeta();

        if (meta == null) {
            return item;
        }

        meta.setDisplayName(
                "§6§lTree Tokens"
        );

        meta.setLore(
                List.of(
                        "§7Balance: §6"
                                + manager.getTokens(uuid),
                        "§7Used to unlock skill tree nodes."
                )
        );

        meta.addItemFlags(
                ItemFlag.HIDE_ATTRIBUTES,
                ItemFlag.HIDE_ENCHANTS
        );

        item.setItemMeta(meta);

        return item;
    }

    // ─────────────────────────────────────────────────────
    //  Helper: admin unlock-all button
    // ─────────────────────────────────────────────────────

    private static ItemStack buildAdminUnlockButton() {

        ItemStack item =
                new ItemStack(
                        SkillTreeSlots.MAIN_ADMIN_UNLOCK_ICON
                );

        ItemMeta meta =
                item.getItemMeta();

        if (meta == null) {
            return item;
        }

        meta.setDisplayName(
                "§6§lUnlock All"
        );

        meta.setLore(
                List.of(
                        "§7Instantly unlocks every skill node",
                        "§7and biome for this player.",
                        " ",
                        "§c§lAdmin / Owner only"
                )
        );

        meta.addItemFlags(
                ItemFlag.HIDE_ATTRIBUTES,
                ItemFlag.HIDE_ENCHANTS
        );

        applyGlow(meta);

        item.setItemMeta(meta);

        return item;
    }

    // ─────────────────────────────────────────────────────
    //  Helper: tab indicator
    // ─────────────────────────────────────────────────────

    /**
     * Builds a nav icon that represents the currently open tab.
     * It gets the enchanted glow so players can instantly see which section
     * they're browsing without reading the inventory title.
     */
    private static ItemStack tabIndicator(
            Material material,
            String name,
            String lore
    ) {

        ItemStack item =
                new ItemStack(material);

        ItemMeta meta =
                item.getItemMeta();

        if (meta == null) {
            return item;
        }

        meta.setDisplayName(name);
        meta.setLore(List.of(lore));

        meta.addItemFlags(
                ItemFlag.HIDE_ATTRIBUTES,
                ItemFlag.HIDE_ENCHANTS
        );

        applyGlow(meta);

        item.setItemMeta(meta);

        return item;
    }

    // ─────────────────────────────────────────────────────
    //  Shared utilities
    // ─────────────────────────────────────────────────────

    /**
     * Applies the enchantment-glint visual effect to an ItemMeta.
     * Uses the Luck enchantment (harmless, never shown thanks to HIDE_ENCHANTS).
     */
    private static void applyGlow(ItemMeta meta) {

        Enchantment luck =
                Enchantment.getByKey(
                        NamespacedKey.minecraft("luck")
                );

        if (luck != null) {
            meta.addEnchant(
                    luck,
                    1,
                    true
            );
        }
    }

    /**
     * Creates a GUI button.
     *
     * The varargs lore parameter allows the button to have
     * one or more lore lines.
     */
    private static ItemStack button(
            Material material,
            String name,
            String... lore
    ) {

        ItemStack item =
                new ItemStack(material);

        ItemMeta meta =
                item.getItemMeta();

        if (meta == null) {
            return item;
        }

        meta.setDisplayName(name);
        meta.setLore(List.of(lore));

        meta.addItemFlags(
                ItemFlag.HIDE_ATTRIBUTES,
                ItemFlag.HIDE_ENCHANTS
        );

        item.setItemMeta(meta);

        return item;
    }

    private static String prettyName(Material material) {

        String raw =
                material.name()
                        .replace('_', ' ');

        StringBuilder result =
                new StringBuilder();

        for (String word :
                raw.split(" ")) {

            if (!word.isEmpty()) {

                result.append(
                                Character.toUpperCase(
                                        word.charAt(0)
                                )
                        )
                        .append(
                                word.substring(1)
                                        .toLowerCase()
                        )
                        .append(' ');
            }
        }

        return result.toString().trim();
    }

    private static String stripColor(String value) {

        return value.replaceAll(
                "§[0-9a-fk-or]",
                ""
        );
    }
}