package net.islandcore.plugin.tasks;

import net.islandcore.plugin.managers.LevelManager;
import org.bukkit.scheduler.BukkitRunnable;

public class PlaytimeTask extends BukkitRunnable {
    private final LevelManager levels;
    public PlaytimeTask(LevelManager levels) { this.levels = levels; }
    @Override public void run() { levels.flushOnlinePlayers(); }
}
