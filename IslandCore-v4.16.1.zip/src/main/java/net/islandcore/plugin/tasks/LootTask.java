package net.islandcore.plugin.tasks;

import net.islandcore.plugin.data.DataStore;
import net.islandcore.plugin.managers.LevelManager;
import net.islandcore.plugin.skilltree.SkillTreeManager;
import net.islandcore.plugin.ranks.RankManager;
import net.islandcore.plugin.util.CountdownManager;
import net.islandcore.plugin.util.Msg;
import net.islandcore.plugin.util.Symbols;
import net.islandcore.plugin.util.WorldUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Random;

/**
 * Every loot interval:
 *  1. Awards 1 Tree Token to each eligible player.
 *  2. Gives one item drawn from their active skill tree node's pool.
 *
 * The old flat loot table is replaced entirely by the per-player skill tree.
 */
public class LootTask extends BukkitRunnable {

    private final DataStore data;
    private final SkillTreeManager skillTreeManager;
    private final int intervalSeconds;
    private final RankManager rankManager;
    private final LevelManager levels;
    private final Random random = new Random();

    public LootTask(DataStore data, SkillTreeManager skillTreeManager, int intervalSeconds, RankManager rankManager, LevelManager levels) {
        this.data = data;
        this.skillTreeManager = skillTreeManager;
        this.intervalSeconds = intervalSeconds;
        this.rankManager = rankManager;
        this.levels = levels;
    }

    @Override
    public void run() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!WorldUtil.isInOwnWorld(player)) continue;
            if (!data.isLootingActive(player.getUniqueId())) continue;

            // Award a token every cycle
            skillTreeManager.addTokens(player.getUniqueId(), 1);

            // Pick item from skill tree
            ItemStack item = skillTreeManager.pickLoot(player.getUniqueId(), random);
            if (item == null) {
                Msg.send(player, "&7No active skill tree node selected. Use &b/progressiontree &7to pick one.");
                CountdownManager.set(player.getUniqueId(), intervalSeconds);
                continue;
            }

            boolean isFull = isInventoryFull(player, item.getType());
            if (isFull) {
                player.sendMessage(Msg.color("&c" + Symbols.WARNING + " &7Item was not given because inventory is full!"));
            } else {
                player.getInventory().addItem(item);
                CountdownManager.setPreviousItem(player.getUniqueId(), item.getType());
                int pulls = data.incrementLootPulls(player.getUniqueId());
                awardMilestoneXp(player, pulls);
                announcePullMilestone(player, pulls);
            }

            CountdownManager.set(player.getUniqueId(), intervalSeconds);
        }
    }

    private void awardMilestoneXp(Player player, int pulls) {
        int[] milestones = {100, 1000, 5000, 10000, 25000, 50000, 100000};
        int[] rewards = {10, 25, 50, 75, 100, 150, 250};
        for (int i = 0; i < milestones.length; i++) {
            if (pulls == milestones[i] && !data.hasPullMilestone(player.getUniqueId(), milestones[i])) {
                data.markPullMilestone(player.getUniqueId(), milestones[i]);
                levels.addXp(player.getUniqueId(), rewards[i]);
                return;
            }
        }
    }

    private void announcePullMilestone(Player player, int pulls) {
        if (pulls == 100) {
            Msg.send(player, "&aYou just hit 100 pulls! GG");
            return;
        }

        if (pulls == 1000) {
            Msg.send(player, "&aYou just hit 1,000 pulls! GG");
            return;
        }

        if (pulls == 10000 || pulls == 50000 || pulls == 100000) {
            String rankPrefix = rankManager != null
                    ? rankManager.getChatPrefix(player.getUniqueId())
                    : "&7[Member]";
            String numberColour;
            if (pulls == 10000) {
                numberColour = "\u00a7x\u00a7C\u00a7D\u00a77\u00a7F\u00a732"; // bronze
            } else if (pulls == 50000) {
                numberColour = "\u00a7x\u00a7C\u00a7C\u00a7C\u00a7C\u00a7C\u00a7C"; // silver
            } else {
                numberColour = "&6"; // gold
            }
            Bukkit.broadcastMessage(Msg.color(rankPrefix + " &f" + player.getName()
                    + " just hit " + numberColour + String.format("%,d", pulls)
                    + " pulls, &6GG!"));
            return;
        }

        // Every 5,000 pulls, except the three public milestones above.
        if (pulls >= 5000 && pulls % 5000 == 0) {
            Msg.send(player, "&aYou just hit " + String.format("%,d", pulls) + " pulls, GG!");
        }
    }

    private boolean isInventoryFull(Player player, Material itemToGive) {
        if (player.getInventory().firstEmpty() != -1) return false;
        for (ItemStack item : player.getInventory().getStorageContents()) {
            if (item != null && item.getType() == itemToGive && item.getAmount() < item.getMaxStackSize()) {
                return false;
            }
        }
        return true;
    }
}
