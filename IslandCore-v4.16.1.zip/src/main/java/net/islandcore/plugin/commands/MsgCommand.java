package net.islandcore.plugin.commands;

import net.islandcore.plugin.data.DataStore;
import net.islandcore.plugin.friends.BlockManager;
import net.islandcore.plugin.friends.FriendManager;
import net.islandcore.plugin.settings.MsgSetting;
import net.islandcore.plugin.util.Msg;
import net.islandcore.plugin.util.PermissionUtil;
import net.islandcore.plugin.util.ReplyManager;
import net.islandcore.plugin.util.Symbols;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class MsgCommand implements CommandExecutor {

    private final BlockManager blockManager;
    private final DataStore dataStore;
    private final FriendManager friendManager;

    public MsgCommand(BlockManager blockManager, DataStore dataStore, FriendManager friendManager) {
        this.blockManager  = blockManager;
        this.dataStore     = dataStore;
        this.friendManager = friendManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (PermissionUtil.deny(sender, "islandcore.msg")) return true;
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Players only.");
            return true;
        }
        if (args.length < 2) {
            Msg.send(player, "&c" + Symbols.WARNING + " &7Usage: /msg <player> <message>");
            return true;
        }

        Player targetPlayer = Bukkit.getPlayer(args[0]);
        if (targetPlayer == null) {
            Msg.send(player, "&c" + Symbols.WARNING + " &7" + args[0] + " is offline!");
            return true;
        }

        // Block check — show generic "offline" so the sender can't detect a block.
        if (blockManager.isBlocked(player.getUniqueId(), targetPlayer.getUniqueId())) {
            Msg.send(player, "&c" + Symbols.WARNING + " &7" + args[0] + " is offline!");
            return true;
        }

        // Msg setting check on the target.
        MsgSetting targetSetting = dataStore.getMsgSetting(targetPlayer.getUniqueId());
        if (targetSetting == MsgSetting.OFF) {
            Msg.send(player, "&c" + Symbols.WARNING + " &7" + args[0] + " has disabled private messages.");
            return true;
        }
        if (targetSetting == MsgSetting.FRIENDS_ONLY
                && !friendManager.areFriends(player.getUniqueId(), targetPlayer.getUniqueId())) {
            Msg.send(player, "&c" + Symbols.WARNING + " &7" + args[0] + " only accepts messages from friends.");
            return true;
        }

        String text = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
        String formatted = "&c[&e" + player.getName() + " &c=> &e" + targetPlayer.getName() + "&c] &b" + text;
        Msg.send(player, formatted);
        Msg.send(targetPlayer, formatted);

        ReplyManager.setReplyTarget(player.getUniqueId(), targetPlayer.getUniqueId());
        ReplyManager.setReplyTarget(targetPlayer.getUniqueId(), player.getUniqueId());
        return true;
    }
}
