package net.islandcore.plugin.commands;

import net.islandcore.plugin.gui.LevelGUI;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class LevelCommand implements CommandExecutor {
    private final LevelGUI gui;
    public LevelCommand(LevelGUI gui) { this.gui = gui; }
    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage("Players only."); return true; }
        gui.open(player);
        return true;
    }
}
