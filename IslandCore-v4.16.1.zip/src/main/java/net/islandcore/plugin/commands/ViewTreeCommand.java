package net.islandcore.plugin.commands;

import net.islandcore.plugin.skilltree.SkillTreeGUI;
import net.islandcore.plugin.util.Msg;
import net.islandcore.plugin.util.PermissionUtil;
import net.islandcore.plugin.util.Symbols;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class ViewTreeCommand implements CommandExecutor, TabCompleter {
    private final SkillTreeGUI gui;

    public ViewTreeCommand(SkillTreeGUI gui) {
        this.gui = gui;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (PermissionUtil.deny(sender, "islandcore.viewtree")) return true;
        if (!(sender instanceof Player viewer)) {
            sender.sendMessage("Players only.");
            return true;
        }
        if (args.length != 1) {
            Msg.send(viewer, "&c" + Symbols.WARNING + " &7Usage: /viewtree <player>");
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            OfflinePlayer offline = Bukkit.getOfflinePlayer(args[0]);
            if (!offline.hasPlayedBefore() || offline.getName() == null) {
                Msg.send(viewer, "&c" + Symbols.WARNING + " &7That player could not be found.");
                return true;
            }
            target = offline.getPlayer();
        }

        if (target == null) {
            Msg.send(viewer, "&c" + Symbols.WARNING + " &7That player is offline. /viewtree currently requires them to be online.");
            return true;
        }

        gui.openTreeTab(viewer, target.getUniqueId(), true);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!PermissionUtil.has(sender, "islandcore.viewtree") || args.length != 1) return List.of();
        String input = args[0].toLowerCase();
        List<String> names = new ArrayList<>();
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.getName().toLowerCase().startsWith(input)) names.add(player.getName());
        }
        return names;
    }
}
