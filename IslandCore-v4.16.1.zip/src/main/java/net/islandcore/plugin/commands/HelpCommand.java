package net.islandcore.plugin.commands;

import net.islandcore.plugin.util.Msg;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import java.util.List;

/**
 * Public command help. Staff-only commands are deliberately omitted so normal
 * players see only commands intended for them.
 */
public class HelpCommand implements CommandExecutor {
    private static final List<String> COMMANDS = List.of(
            "/visit <player> &8- &7Visit another player's island",
            "/home &8- &7Return to your island",
            "/setspawn &8- &7Set your island spawn",
            "/myisland &8- &7View your island information",
            "/msg <player> <message> &8- &7Send a private message",
            "/reply <message> &8- &7Reply to a private message",
            "/rate <player> <1-5> &8- &7Rate an island",
            "/topislands &8- &7View the island leaderboard",
            "/toggle &8- &7Toggle random item looting",
            "/toggleislandvisits &8- &7Toggle visits to your island",
            "/progressiontree &8- &7Open your progression tree",
            "/myrank &8- &7Choose your displayed rank",
            "/friend <add|remove|accept|deny|list> [player] &8- &7Manage friends",
            "/trade <player|accept|deny|cancel> [player] &8- &7Trade with another player",
            "/report <player> <reason> &8- &7Report a player",
            "/reportisland <player> <reason> &8- &7Report an island",
            "/level &8- &7View your level and XP",
            "/playtime &8- &7View and save your playtime",
            "/help &8- &7Show this command list"
    );

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Msg.send(sender, "&8&m----------&r &b&lIslandCore Help &8&m----------");
        for (String line : COMMANDS) Msg.send(sender, "&b" + line);
        Msg.send(sender, "&8&m-------------------------------------------");
        return true;
    }
}
