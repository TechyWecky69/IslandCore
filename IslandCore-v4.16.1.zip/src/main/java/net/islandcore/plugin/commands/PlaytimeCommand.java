package net.islandcore.plugin.commands;

import net.islandcore.plugin.managers.LevelManager;
import net.islandcore.plugin.util.Msg;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PlaytimeCommand implements CommandExecutor {
    private final LevelManager levels;
    public PlaytimeCommand(LevelManager levels) { this.levels = levels; }
    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage("Players only."); return true; }
        levels.startTracking(player.getUniqueId());
        levels.flushPlaytime(player.getUniqueId(), true);
        long seconds = levels.getPlaytimeSeconds(player.getUniqueId());
        Msg.send(player, "&8&m----------&r &b&lPlaytime &8&m----------");
        Msg.send(player, "&7Playtime: &e" + LevelManager.formatPlaytime(seconds));
        Msg.send(player, "&7Level: &a" + levels.getLevel(player.getUniqueId()));
        Msg.send(player, "&7XP: &d" + levels.getXp(player.getUniqueId()) + "&7/100");
        Msg.send(player, "&8&m--------------------------------------");
        return true;
    }
}
