package net.islandcore.plugin.commands;

import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import net.islandcore.plugin.util.PermissionUtil;

import java.util.Collections;
import java.util.List;

public class UnbanCommand implements CommandExecutor, TabCompleter {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (PermissionUtil.deny(sender, "islandcore.unban")) return true;

        if (args.length < 1) {
            sender.sendMessage("§cUsage: /unban <player>");
            return true;
        }

        String targetName = args[0];

        BanList nameBanList = Bukkit.getBanList(BanList.Type.NAME);

        if (!nameBanList.isBanned(targetName)) {
            sender.sendMessage("§c" + targetName + " is not banned.");
            return true;
        }

        nameBanList.pardon(targetName);
        sender.sendMessage("§aSuccessfully unbanned §e" + targetName + "§a.");

        return true;
    }

    @Override
    public List<String> onTabComplete(
            CommandSender sender,
            Command command,
            String alias,
            String[] args
    ) {
        if (args.length == 1) {
            return null;
        }

        return Collections.emptyList();
    }
}