package net.islandcore.plugin.commands;

import net.islandcore.plugin.managers.MuteManager;
import net.islandcore.plugin.util.DurationUtil;
import net.islandcore.plugin.util.Msg;
import net.islandcore.plugin.util.PermissionUtil;
import net.islandcore.plugin.util.Symbols;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.Arrays;
import java.util.stream.Collectors;

public class MuteCommand implements CommandExecutor {
    private final MuteManager muteManager;

    public MuteCommand(MuteManager muteManager) {
        this.muteManager = muteManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (PermissionUtil.deny(sender, "islandcore.mute")) return true;

        if (args.length < 2) {
            Msg.send(sender, "&c" + Symbols.WARNING + " &7Usage: /mute <player> <reason> [duration]");
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            Msg.send(sender, "&4" + args[0] + " is not online!");
            return true;
        }

        String durationToken = null;
        int reasonEnd = args.length;
        if (args.length >= 3 && DurationUtil.isValidToken(args[args.length - 1])) {
            durationToken = args[args.length - 1];
            reasonEnd--;
        }

        String reason = Arrays.stream(args, 1, reasonEnd).collect(Collectors.joining(" ")).trim();
        if (reason.isEmpty()) {
            Msg.send(sender, "&c" + Symbols.WARNING + " &7Please give a reason!");
            return true;
        }

        long expiresAt = 0L;
        String durationLabel = "permanently";
        if (durationToken != null) {
            expiresAt = System.currentTimeMillis() + DurationUtil.millis(durationToken);
            durationLabel = DurationUtil.label(durationToken);
        }

        muteManager.mute(target.getUniqueId(), reason, expiresAt, sender.getName());

        String message = durationToken == null
                ? "&4You have been permanently muted.\\n&fReason: " + reason
                : "&4You have been muted for " + durationLabel + ".\\n&fReason: " + reason;
        Msg.send(target, message);

        if (durationToken == null) {
            Msg.send(sender, "&cMuted &e" + target.getName() + "&c permanently.");
        } else {
            Msg.send(sender, "&cMuted &e" + target.getName() + "&c for &e" + durationLabel + "&c.");
        }
        return true;
    }
}
