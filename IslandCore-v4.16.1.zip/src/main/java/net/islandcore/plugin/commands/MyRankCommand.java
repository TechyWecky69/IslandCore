package net.islandcore.plugin.commands;

import net.islandcore.plugin.ranks.Rank;
import net.islandcore.plugin.ranks.RankManager;
import net.islandcore.plugin.util.Msg;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.UUID;

/** /myrank - choose which of your held ranks is displayed. */
public class MyRankCommand implements org.bukkit.command.CommandExecutor, Listener {
    private static final String TITLE = Msg.color("&7[&6✦&7] &fYour Ranks");
    private final RankManager ranks;

    public MyRankCommand(RankManager ranks) { this.ranks = ranks; }

    @Override
    public boolean onCommand(org.bukkit.command.CommandSender sender, org.bukkit.command.Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage("Players only."); return true; }
        open(player);
        return true;
    }

    public void open(Player player) {
        List<Rank> held = ranks.getRanks(player.getUniqueId());
        Inventory inv = Bukkit.createInventory(null, 9, TITLE);
        for (int i = 0; i < Math.min(9, held.size()); i++) {
            Rank rank = held.get(i);
            ItemStack paper = new ItemStack(Material.PAPER);
            ItemMeta meta = paper.getItemMeta();
            meta.setDisplayName(Msg.color(rank.getPrefix()));
            meta.setLore(List.of(
                    Msg.color("&7Click to display this rank."),
                    Msg.color(ranks.getDisplayRank(player.getUniqueId()) == rank ? "&aCurrently displayed" : "&8Not currently displayed")
            ));
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
            paper.setItemMeta(meta);
            inv.setItem(i, paper);
        }
        player.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!event.getView().getTitle().equals(TITLE)) return;
        event.setCancelled(true);
        if (event.getRawSlot() < 0 || event.getRawSlot() >= 9) return;
        List<Rank> held = ranks.getRanks(player.getUniqueId());
        int slot = event.getRawSlot();
        if (slot >= held.size()) return;
        Rank chosen = held.get(slot);
        ranks.setDisplayRank(player.getUniqueId(), chosen);
        Msg.send(player, "&aYour displayed rank is now " + chosen.getPrefix() + "&a.");
        open(player);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTitle().equals(TITLE)) event.setCancelled(true);
    }
}
