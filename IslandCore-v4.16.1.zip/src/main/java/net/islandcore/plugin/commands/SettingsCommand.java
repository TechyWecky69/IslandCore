package net.islandcore.plugin.commands;

import net.islandcore.plugin.gui.SettingsGUI;
import net.islandcore.plugin.util.PermissionUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SettingsCommand implements CommandExecutor {

    private final SettingsGUI settingsGUI;

    public SettingsCommand(SettingsGUI settingsGUI) {
        this.settingsGUI = settingsGUI;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Players only.");
            return true;
        }
        settingsGUI.open(player);
        return true;
    }
}
