package net.islandcore.plugin.commands;

import net.islandcore.plugin.friends.BlockManager;
import net.islandcore.plugin.friends.FriendManager;
import net.islandcore.plugin.util.Msg;
import net.islandcore.plugin.util.Symbols;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * /block <player>          — block a player
 * /block remove <player>   — unblock a player
 * /block list              — list everyone you have blocked
 *
 * Effects of blocking:
 *  - The blocked player cannot visit your island.
 *  - Neither side can send private messages to the other.
 *  - Any existing friendship between the two players is removed.
 */
public class BlockCommand implements CommandExecutor, TabCompleter {

    private final BlockManager blockManager;
    private final FriendManager friendManager;

    public BlockCommand(BlockManager blockManager, FriendManager friendManager) {
        this.blockManager = blockManager;
        this.friendManager = friendManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Players only.");
            return true;
        }

        if (args.length == 0) {
            sendUsage(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "remove" -> handleRemove(player, args);
            case "list"   -> handleList(player);
            default       -> handleBlock(player, args[0]);
        }
        return true;
    }

    // ── /block <player> ───────────────────────────────────────────────────────

    private void handleBlock(Player player, String targetName) {
        OfflinePlayer target = Bukkit.getOfflinePlayer(targetName);

        if (target.getUniqueId().equals(player.getUniqueId())) {
            Msg.send(player, "&c" + Symbols.WARNING + " &7You can't block yourself!");
            return;
        }

        // Reject purely unknown names (no UUID has ever been assigned to them).
        if (!target.hasPlayedBefore() && !target.isOnline()) {
            Msg.send(player, "&c" + Symbols.WARNING + " &7Player &e" + targetName + " &7has never played on this server!");
            return;
        }

        if (blockManager.hasBlocked(player.getUniqueId(), target.getUniqueId())) {
            Msg.send(player, "&c" + Symbols.WARNING + " &7You have already blocked &e" + targetName + "&7.");
            return;
        }

        // Remove friendship if one exists.
        if (friendManager.areFriends(player.getUniqueId(), target.getUniqueId())) {
            friendManager.removeFriend(player.getUniqueId(), target.getUniqueId());
            Msg.send(player, "&7You have been removed from each other's friends list.");
            Player targetOnline = target.getPlayer();
            if (targetOnline != null) {
                Msg.send(targetOnline, "&7You have been removed from &e" + player.getName() + "&7's friends list.");
            }
        }

        // Also cancel any pending friend requests between the two.
        friendManager.denyRequest(player.getUniqueId(), target.getUniqueId());
        friendManager.denyRequest(target.getUniqueId(), player.getUniqueId());

        blockManager.block(player.getUniqueId(), target.getUniqueId());
        Msg.send(player, "&c" + Symbols.CHECK + " &7You have blocked &e" + targetName + "&7. "
                + "They can no longer visit your island or message you.");
    }

    // ── /block remove <player> ────────────────────────────────────────────────

    private void handleRemove(Player player, String[] args) {
        if (args.length < 2) {
            Msg.send(player, "&c" + Symbols.WARNING + " &7Usage: /block remove <player>");
            return;
        }

        String targetName = args[1];
        OfflinePlayer target = Bukkit.getOfflinePlayer(targetName);

        if (!blockManager.hasBlocked(player.getUniqueId(), target.getUniqueId())) {
            Msg.send(player, "&c" + Symbols.WARNING + " &7You haven't blocked &e" + targetName + "&7.");
            return;
        }

        blockManager.unblock(player.getUniqueId(), target.getUniqueId());
        Msg.send(player, "&a" + Symbols.CHECK + " &7You have unblocked &e" + targetName + "&7.");
    }

    // ── /block list ───────────────────────────────────────────────────────────

    private void handleList(Player player) {
        Set<UUID> blockedSet = blockManager.getBlockedBy(player.getUniqueId());

        Msg.send(player, "&c&lBlocked Players&7--------------------");
        if (blockedSet.isEmpty()) {
            Msg.send(player, "&7You haven't blocked anyone.");
        } else {
            List<OfflinePlayer> sorted = new ArrayList<>();
            for (UUID uuid : blockedSet) sorted.add(Bukkit.getOfflinePlayer(uuid));
            sorted.sort((a, b) -> {
                String nameA = a.getName() == null ? "" : a.getName();
                String nameB = b.getName() == null ? "" : b.getName();
                return nameA.compareToIgnoreCase(nameB);
            });
            for (OfflinePlayer op : sorted) {
                String name = op.getName() == null ? op.getUniqueId().toString() : op.getName();
                Msg.send(player, "&7- &e" + name + " &8(/block remove " + name + ")");
            }
        }
        Msg.send(player, "&7-----------------------------");
    }

    // ── Usage ─────────────────────────────────────────────────────────────────

    private void sendUsage(Player player) {
        Msg.send(player, "&c" + Symbols.WARNING + " &7Usage: /block <player> &8| &7/block remove <player> &8| &7/block list");
    }

    // ── Tab completion ────────────────────────────────────────────────────────

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!(sender instanceof Player player)) return List.of();

        if (args.length == 1) {
            List<String> options = new ArrayList<>(List.of("remove", "list"));
            for (Player online : Bukkit.getOnlinePlayers()) {
                if (!online.getUniqueId().equals(player.getUniqueId())) {
                    options.add(online.getName());
                }
            }
            return partial(args[0], options);
        }

        if (args.length == 2 && args[0].equalsIgnoreCase("remove")) {
            List<String> names = new ArrayList<>();
            for (UUID uuid : blockManager.getBlockedBy(player.getUniqueId())) {
                OfflinePlayer op = Bukkit.getOfflinePlayer(uuid);
                if (op.getName() != null) names.add(op.getName());
            }
            return partial(args[1], names);
        }

        return List.of();
    }

    private List<String> partial(String input, List<String> options) {
        String lower = input.toLowerCase();
        return options.stream().filter(o -> o.toLowerCase().startsWith(lower)).toList();
    }
}
