package net.islandcore.plugin.commands;

import net.islandcore.plugin.data.DataStore;
import net.islandcore.plugin.friends.FriendManager;
import net.islandcore.plugin.ranks.Rank;
import net.islandcore.plugin.ranks.RankManager;
import net.islandcore.plugin.settings.VisitSetting;
import net.islandcore.plugin.util.IslandVisitorUtil;
import net.islandcore.plugin.util.Msg;
import net.islandcore.plugin.util.PermissionUtil;
import net.islandcore.plugin.util.WorldUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import java.util.UUID;

/**
 * Cycles the island visit setting:
 * PUBLIC -> FRIENDS_ONLY -> DISABLED -> PUBLIC
 *
 * This command mirrors the visit-setting behaviour in SettingsGUI.
 */
public class ToggleIslandVisitsCommand implements CommandExecutor {

    private final DataStore dataStore;
    private final RankManager rankManager;
    private final FriendManager friendManager;

    public ToggleIslandVisitsCommand(DataStore dataStore, RankManager rankManager,
                                     FriendManager friendManager) {
        this.dataStore = dataStore;
        this.rankManager = rankManager;
        this.friendManager = friendManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (PermissionUtil.deny(sender, "islandcore.toggleislandvisits")) return true;

        if (!(sender instanceof Player player)) {
            sender.sendMessage("Players only.");
            return true;
        }

        if (!WorldUtil.isInOwnWorld(player)) {
            Msg.send(player, "&c⚠ &7You can only change your island visit settings from your own island.");
            return true;
        }

        UUID ownerId = player.getUniqueId();
        VisitSetting next = dataStore.getVisitSetting(ownerId).next();
        dataStore.setVisitSetting(ownerId, next);

        switch (next) {
            case DISABLED -> {
                int kicked = IslandVisitorUtil.kickVisitors(ownerId, rankManager);
                String suffix = kicked > 0 ? " &7Kicked &b" + kicked + "&7 visitor(s)." : "";
                Msg.send(player, "&cIsland visits set to &cDisabled&c." + suffix);
            }
            case FRIENDS_ONLY -> {
                kickNonFriendVisitors(ownerId);
                Msg.send(player, "&eIsland visits set to &eFriends Only&e.");
            }
            case PUBLIC -> Msg.send(player, "&aIsland visits set to &aPublic&a.");
        }

        return true;
    }

    private void kickNonFriendVisitors(UUID ownerId) {
        var island = WorldUtil.getIslandWorld(ownerId);
        if (island == null) return;

        for (Player visitor : Bukkit.getOnlinePlayers()) {
            if (!visitor.getWorld().equals(island)) continue;
            if (visitor.getUniqueId().equals(ownerId)) continue;
            if (visitor.isOp()) continue;
            if (rankManager.hasAtLeast(visitor.getUniqueId(), Rank.HELPER)) continue;
            if (friendManager.areFriends(ownerId, visitor.getUniqueId())) continue;

            var ownWorld = WorldUtil.getIslandWorld(visitor.getUniqueId());
            if (ownWorld != null) {
                visitor.teleport(ownWorld.getSpawnLocation());
            } else if (!Bukkit.getWorlds().isEmpty()) {
                visitor.teleport(Bukkit.getWorlds().get(0).getSpawnLocation());
            }
            visitor.setAllowFlight(false);
            Msg.send(visitor, "&c⚠ &7You were removed because this island is now Friends Only.");
        }
    }
}
