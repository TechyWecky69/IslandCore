package net.islandcore.plugin.gui;

import net.islandcore.plugin.managers.LevelManager;
import net.islandcore.plugin.util.Msg;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/** Informational leveling GUI. */
public class LevelGUI implements Listener {
    private final LevelManager levels;
    public LevelGUI(LevelManager levels) { this.levels = levels; }

    public void open(Player player) {
        Holder holder = new Holder();
        Inventory inv = Bukkit.createInventory(holder, 27, Msg.color("&8&lYour Level"));
        holder.inventory = inv;

        ItemStack header = item(Material.EXPERIENCE_BOTTLE,
                "&a&lLevel " + levels.getLevel(player.getUniqueId()),
                List.of(
                        "&7Total XP: &d" + levels.getTotalXp(player.getUniqueId()),
                        "&7Current XP: &d" + levels.getXp(player.getUniqueId()) + "&7/100",
                        "&7XP to next level: &d" + (100 - levels.getXp(player.getUniqueId()))
                ));
        inv.setItem(4, header);

        inv.setItem(10, item(Material.NETHER_STAR, "&e&lUnlock Nodes", List.of(
                "&7Unlocking a progression node gives",
                "&a+200 XP &7(2 levels).")));
        inv.setItem(12, item(Material.ENCHANTED_BOOK, "&b&lUpgrade Item Chances", List.of(
                "&7Every Rare/Epic chance upgrade gives",
                "&a+10 XP &7per upgrade.")));
        inv.setItem(14, item(Material.CLOCK, "&6&lPlaytime", List.of(
                "&7Gain &a+10 XP &7every hour played.",
                "&7Playtime XP stops after &e100 hours&7.",
                "&7Current: &e" + LevelManager.formatPlaytime(levels.getPlaytimeSeconds(player.getUniqueId())))));
        inv.setItem(16, item(Material.FIREWORK_ROCKET, "&d&lPull Milestones", List.of(
                "&7100 pulls: &a+10 XP",
                "&71,000 pulls: &a+25 XP",
                "&75,000 pulls: &a+50 XP",
                "&710,000 pulls: &a+75 XP",
                "&725,000 pulls: &a+100 XP",
                "&750,000 pulls: &a+150 XP",
                "&7100,000 pulls: &a+250 XP")));

        for (int i = 0; i < inv.getSize(); i++) {
            if (inv.getItem(i) == null) inv.setItem(i, item(Material.GRAY_STAINED_GLASS_PANE, " ", List.of()));
        }
        player.openInventory(inv);
    }

    private ItemStack item(Material material, String name, List<String> lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Msg.color(name));
            meta.setLore(lore.stream().map(Msg::color).toList());
            stack.setItemMeta(meta);
        }
        return stack;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof Holder)) return;
        event.setCancelled(true);
    }

    private static final class Holder implements InventoryHolder {
        private Inventory inventory;
        @Override public Inventory getInventory() { return inventory; }
    }
}
