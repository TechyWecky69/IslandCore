package net.islandcore.plugin.gui;

import net.islandcore.plugin.data.DataStore;
import net.islandcore.plugin.friends.FriendManager;
import net.islandcore.plugin.managers.IslandManager;
import net.islandcore.plugin.ranks.RankManager;
import net.islandcore.plugin.settings.FriendRequestSetting;
import net.islandcore.plugin.settings.MsgSetting;
import net.islandcore.plugin.settings.VisitSetting;
import net.islandcore.plugin.util.IslandVisitorUtil;
import net.islandcore.plugin.util.Msg;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * A 1-row (9-slot) settings GUI opened by /settings.
 *
 * Slot 2 — Island Visitors  (OAK_FENCE)   — PUBLIC / FRIENDS_ONLY / DISABLED
 * Slot 4 — Private Messages (NAME_TAG)     — PUBLIC / FRIENDS_ONLY / OFF
 * Slot 6 — Friend Requests  (REPEATER)     — ENABLED / DISABLED
 *
 * Each click cycles to the next value and refreshes the item in place.
 */
public class SettingsGUI implements Listener {

    private static final String TITLE = "§8Island Settings";
    private static final int SLOT_VISIT   = 2;
    private static final int SLOT_MSG     = 4;
    private static final int SLOT_FRIENDS = 6;

    private final DataStore dataStore;
    private final RankManager rankManager;
    private final IslandManager islandManager;
    private final FriendManager friendManager;

    /** Players who currently have the GUI open. */
    private final Map<UUID, Inventory> open = new ConcurrentHashMap<>();

    public SettingsGUI(DataStore dataStore, RankManager rankManager,
                       IslandManager islandManager, FriendManager friendManager) {
        this.dataStore    = dataStore;
        this.rankManager  = rankManager;
        this.islandManager = islandManager;
        this.friendManager = friendManager;
    }

    // ── Open ──────────────────────────────────────────────────────────────────

    public void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 9, TITLE);
        populate(inv, player.getUniqueId());
        open.put(player.getUniqueId(), inv);
        player.openInventory(inv);
    }

    // ── Population ────────────────────────────────────────────────────────────

    private void populate(Inventory inv, UUID uuid) {
        // Fill unused slots with grey glass
        ItemStack filler = makeItem(Material.GRAY_STAINED_GLASS_PANE, "§8", List.of());
        for (int i = 0; i < 9; i++) inv.setItem(i, filler);

        inv.setItem(SLOT_VISIT,   buildVisitItem(uuid));
        inv.setItem(SLOT_MSG,     buildMsgItem(uuid));
        inv.setItem(SLOT_FRIENDS, buildFriendRequestItem(uuid));
    }

    private ItemStack buildVisitItem(UUID uuid) {
        VisitSetting current = dataStore.getVisitSetting(uuid);
        return makeItem(Material.OAK_FENCE, "§fIsland Visitors", List.of(
                "§7Who can visit your island.",
                "",
                "§7Current: " + current.displayName(),
                "",
                settingLine(VisitSetting.PUBLIC,       current),
                settingLine(VisitSetting.FRIENDS_ONLY, current),
                settingLine(VisitSetting.DISABLED,     current),
                "",
                "§eClick to cycle"
        ));
    }

    private ItemStack buildMsgItem(UUID uuid) {
        MsgSetting current = dataStore.getMsgSetting(uuid);
        return makeItem(Material.NAME_TAG, "§fPrivate Messages", List.of(
                "§7Who can send you private messages.",
                "",
                "§7Current: " + current.displayName(),
                "",
                settingLine(MsgSetting.PUBLIC,       current),
                settingLine(MsgSetting.FRIENDS_ONLY, current),
                settingLine(MsgSetting.OFF,          current),
                "",
                "§eClick to cycle"
        ));
    }

    private ItemStack buildFriendRequestItem(UUID uuid) {
        FriendRequestSetting current = dataStore.getFriendRequestSetting(uuid);
        return makeItem(Material.REPEATER, "§fFriend Requests", List.of(
                "§7Whether players can send you friend requests.",
                "",
                "§7Current: " + current.displayName(),
                "",
                settingLine(FriendRequestSetting.ENABLED,  current),
                settingLine(FriendRequestSetting.DISABLED, current),
                "",
                "§eClick to cycle"
        ));
    }

    /** Renders a line with an arrow marker next to the active value. */
    private <E extends Enum<E>> String settingLine(E value, E current) {
        boolean active = value == current;
        String label = value instanceof VisitSetting v       ? v.displayName()
                     : value instanceof MsgSetting m          ? m.displayName()
                     : ((FriendRequestSetting) value).displayName();
        return (active ? "§e▶ " : "§8  ") + label;
    }

    // ── Click handling ────────────────────────────────────────────────────────

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        Inventory playerGui = open.get(player.getUniqueId());
        if (playerGui == null || !event.getInventory().equals(playerGui)) return;

        event.setCancelled(true);

        int slot = event.getSlot();
        UUID uuid = player.getUniqueId();

        switch (slot) {
            case SLOT_VISIT   -> cycleVisit(player, uuid);
            case SLOT_MSG     -> cycleMsg(player, uuid);
            case SLOT_FRIENDS -> cycleFriendRequest(player, uuid);
        }
    }

    private void cycleVisit(Player player, UUID uuid) {
        VisitSetting next = dataStore.getVisitSetting(uuid).next();
        dataStore.setVisitSetting(uuid, next);

        // Kick visitors immediately when moving to DISABLED or FRIENDS_ONLY.
        if (next == VisitSetting.DISABLED) {
            int kicked = IslandVisitorUtil.kickVisitors(uuid, rankManager);
            String suffix = kicked > 0 ? " §7Kicked §b" + kicked + "§7 visitor(s)." : "";
            Msg.send(player, "§cIsland visits set to §cDisabled§c." + suffix);
        } else if (next == VisitSetting.FRIENDS_ONLY) {
            kickNonFriendVisitors(player, uuid);
            Msg.send(player, "§eIsland visits set to §eFriends Only§e.");
        } else {
            Msg.send(player, "§aIsland visits set to §aPublic§a.");
        }

        refreshItem(player, SLOT_VISIT, buildVisitItem(uuid));
    }

    private void kickNonFriendVisitors(Player owner, UUID ownerId) {
        var island = net.islandcore.plugin.util.WorldUtil.getIslandWorld(ownerId);
        if (island == null) return;

        for (Player visitor : Bukkit.getOnlinePlayers()) {
            if (!visitor.getWorld().equals(island)) continue;
            if (visitor.getUniqueId().equals(ownerId)) continue;
            if (visitor.isOp()) continue;
            if (rankManager.hasAtLeast(visitor.getUniqueId(), net.islandcore.plugin.ranks.Rank.HELPER)) continue;
            if (friendManager.areFriends(ownerId, visitor.getUniqueId())) continue;

            var ownWorld = net.islandcore.plugin.util.WorldUtil.getIslandWorld(visitor.getUniqueId());
            if (ownWorld != null) {
                visitor.teleport(ownWorld.getSpawnLocation());
            } else if (!Bukkit.getWorlds().isEmpty()) {
                visitor.teleport(Bukkit.getWorlds().get(0).getSpawnLocation());
            }
            visitor.setAllowFlight(false);
            net.islandcore.plugin.util.TeleportCooldownManager.clear(visitor.getUniqueId());
            Msg.send(visitor, "§c⚠ §7You were removed because this island is now Friends Only.");
        }
    }

    private void cycleMsg(Player player, UUID uuid) {
        MsgSetting next = dataStore.getMsgSetting(uuid).next();
        dataStore.setMsgSetting(uuid, next);
        Msg.send(player, "§fPrivate messages set to " + next.displayName() + "§f.");
        refreshItem(player, SLOT_MSG, buildMsgItem(uuid));
    }

    private void cycleFriendRequest(Player player, UUID uuid) {
        FriendRequestSetting next = dataStore.getFriendRequestSetting(uuid).next();
        dataStore.setFriendRequestSetting(uuid, next);
        Msg.send(player, "§fFriend requests set to " + next.displayName() + "§f.");
        refreshItem(player, SLOT_FRIENDS, buildFriendRequestItem(uuid));
    }

    private void refreshItem(Player player, int slot, ItemStack item) {
        Inventory inv = open.get(player.getUniqueId());
        if (inv == null) return;
        inv.setItem(slot, item);
        player.updateInventory();
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        Inventory playerGui = open.get(player.getUniqueId());
        if (playerGui != null && event.getInventory().equals(playerGui)) {
            open.remove(player.getUniqueId());
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private ItemStack makeItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.setDisplayName(Msg.color(name));
        meta.setLore(lore.stream().map(Msg::color).toList());
        item.setItemMeta(meta);
        return item;
    }
}
