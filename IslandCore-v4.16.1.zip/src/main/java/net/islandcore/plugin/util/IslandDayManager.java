package net.islandcore.plugin.util;

import net.islandcore.plugin.data.DataStore;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.world.WorldLoadEvent;
import org.bukkit.event.world.WorldUnloadEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.UUID;

/**
 * Keeps each island's day counter tied to that island world.
 *
 * The actual Minecraft full-time is persisted when an island unloads and
 * restored when it loads. Unloaded worlds therefore cannot advance their day.
 */
public final class IslandDayManager implements Listener {
    private final JavaPlugin plugin;
    private final DataStore data;

    public IslandDayManager(JavaPlugin plugin, DataStore data) {
        this.plugin = plugin;
        this.data = data;
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent event) {
        UUID owner = WorldUtil.getIslandOwner(event.getWorld());
        if (owner == null) return;

        long saved = data.getIslandFullTime(owner);
        if (saved != Long.MIN_VALUE) {
            event.getWorld().setFullTime(Math.max(0L, saved));
        }
    }

    @EventHandler
    public void onWorldUnload(WorldUnloadEvent event) {
        UUID owner = WorldUtil.getIslandOwner(event.getWorld());
        if (owner == null) return;

        data.setIslandFullTime(owner, event.getWorld().getFullTime(), true);
    }

    /** Returns the current day for a loaded island, or its last persisted day when unloaded. */
    public long getDay(UUID owner) {
        World world = WorldUtil.getIslandWorld(owner);
        if (world != null) {
            long day = (world.getFullTime() / 24000L) + 1L;
            data.setIslandFullTime(owner, world.getFullTime(), false);
            return day;
        }

        long saved = data.getIslandFullTime(owner);
        return saved == Long.MIN_VALUE ? 0L : (saved / 24000L) + 1L;
    }

    /** Restore persisted times for island worlds that were already loaded before this plugin enabled. */
    public void restoreLoadedWorlds() {
        for (World world : Bukkit.getWorlds()) {
            UUID owner = WorldUtil.getIslandOwner(world);
            if (owner == null) continue;
            long saved = data.getIslandFullTime(owner);
            if (saved != Long.MIN_VALUE) world.setFullTime(Math.max(0L, saved));
        }
    }

    /** Save all loaded island times during a clean plugin shutdown. */
    public void saveLoadedWorlds() {
        for (World world : Bukkit.getWorlds()) {
            UUID owner = WorldUtil.getIslandOwner(world);
            if (owner != null) {
                data.setIslandFullTime(owner, world.getFullTime(), false);
            }
        }
        data.save();
    }
}
