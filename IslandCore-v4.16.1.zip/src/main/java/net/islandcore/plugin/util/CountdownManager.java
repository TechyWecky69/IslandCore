package net.islandcore.plugin.util;

import java.util.Map;
import org.bukkit.Material;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Tracks the "next loot item in N seconds" countdown per player (transient, like the original's local variable). */
public final class CountdownManager {

    private static final Map<UUID, Integer> COUNTDOWNS = new ConcurrentHashMap<>();
    private static final Map<UUID, String> PREVIOUS_ITEMS = new ConcurrentHashMap<>();

    private CountdownManager() {}

    public static void set(UUID uuid, int seconds) {
        COUNTDOWNS.put(uuid, seconds);
    }

    public static void setPreviousItem(UUID uuid, Material material) {
        PREVIOUS_ITEMS.put(uuid, material == null ? "None" : formatMaterial(material));
    }

    public static String getPreviousItem(UUID uuid) {
        return PREVIOUS_ITEMS.getOrDefault(uuid, "None");
    }

    private static String formatMaterial(Material material) {
        String[] parts = material.name().toLowerCase().split("_");
        StringBuilder result = new StringBuilder();
        for (String part : parts) {
            if (part.isEmpty()) continue;
            if (result.length() > 0) result.append(' ');
            result.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return result.toString();
    }

    public static int get(UUID uuid) {
        return COUNTDOWNS.getOrDefault(uuid, 0);
    }

    public static void decrement(UUID uuid) {
        COUNTDOWNS.merge(uuid, -1, Integer::sum);
    }

    public static void remove(UUID uuid) {
        COUNTDOWNS.remove(uuid);
        PREVIOUS_ITEMS.remove(uuid);
    }
}
