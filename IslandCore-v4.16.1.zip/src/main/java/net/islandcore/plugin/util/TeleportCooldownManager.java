package net.islandcore.plugin.util;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.islandcore.plugin.ranks.Rank;

public final class TeleportCooldownManager {
    private static final Map<UUID, Long> LAST_TELEPORT = new ConcurrentHashMap<>();
    private static final long DEFAULT_COOLDOWN_MILLIS = 10_000L;
    private static final Map<UUID, Long> CUSTOM_COOLDOWNS = new ConcurrentHashMap<>();
    private TeleportCooldownManager() {}

    public static long remainingSeconds(UUID uuid) {
        Long last = LAST_TELEPORT.get(uuid);
        if (last == null) return 0;
        long cooldown = CUSTOM_COOLDOWNS.getOrDefault(uuid, DEFAULT_COOLDOWN_MILLIS);
        long remaining = cooldown - (System.currentTimeMillis() - last);
        if (remaining <= 0) { LAST_TELEPORT.remove(uuid); return 0; }
        return (remaining + 999L) / 1000L;
    }
    public static void setCooldown(UUID uuid, long millis) {
        CUSTOM_COOLDOWNS.put(uuid, Math.max(0L, millis));
        if (millis <= 0) LAST_TELEPORT.remove(uuid);
    }
    public static void configureForRank(UUID uuid, Rank rank) {
        if (rank.atLeast(Rank.MVP_PLUS)) setCooldown(uuid, 0L);
        else if (rank.atLeast(Rank.MVP)) setCooldown(uuid, 5_000L);
        else setCooldown(uuid, DEFAULT_COOLDOWN_MILLIS);
    }
    public static boolean isOnCooldown(UUID uuid) { return remainingSeconds(uuid) > 0; }
    public static void markTeleport(UUID uuid) { LAST_TELEPORT.put(uuid, System.currentTimeMillis()); }
    public static void clear(UUID uuid) { LAST_TELEPORT.remove(uuid); }
    public static void remove(UUID uuid) { LAST_TELEPORT.remove(uuid); CUSTOM_COOLDOWNS.remove(uuid); }
}
