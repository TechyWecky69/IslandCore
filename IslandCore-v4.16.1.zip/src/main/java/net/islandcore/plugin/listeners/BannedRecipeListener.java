package net.islandcore.plugin.listeners;

import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Prevents recipes listed in config.yml from being crafted.
 *
 * Entries are Bukkit Material names (for example ENCHANTING_TABLE) and are
 * matched against the resulting crafted item.
 */
public class BannedRecipeListener implements Listener {

    private final Set<Material> bannedResults = new HashSet<>();

    public BannedRecipeListener(JavaPlugin plugin) {
        for (String entry : plugin.getConfig().getStringList("banned-recipes")) {
            try {
                bannedResults.add(Material.valueOf(entry.trim().toUpperCase(Locale.ROOT)));
            } catch (IllegalArgumentException ignored) {
                plugin.getLogger().warning("Unknown banned recipe material: " + entry);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPrepareCraft(PrepareItemCraftEvent event) {
        ItemStack result = event.getInventory().getResult();
        if (isBanned(result)) {
            event.getInventory().setResult(null);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCraft(CraftItemEvent event) {
        if (isBanned(event.getCurrentItem())) {
            event.setCancelled(true);
        }
    }

    private boolean isBanned(ItemStack item) {
        return item != null && !item.getType().isAir() && bannedResults.contains(item.getType());
    }
}
