package net.islandcore.plugin.listeners;

import net.islandcore.plugin.util.BypassUtil;
import net.islandcore.plugin.util.Msg;
import net.islandcore.plugin.util.WorldUtil;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntityPortalEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.event.player.PlayerUnleashEntityEvent;
import org.bukkit.event.world.PortalCreateEvent;

import java.util.List;

public class ProtectionListener implements Listener {

    private static boolean isProtectedSpawnBlock(Location loc) {
        if (loc == null || loc.getWorld() == null) return false;

        Location spawn = loc.getWorld().getSpawnLocation();

        return loc.getBlockX() == spawn.getBlockX()
                && loc.getBlockZ() == spawn.getBlockZ()
                && loc.getBlockY() >= spawn.getBlockY()
                && loc.getBlockY() <= spawn.getBlockY() + 2;
    }

    private static boolean isIsland(World world) {
        return WorldUtil.getIslandOwner(world) != null;
    }

    private static boolean isGuest(Player player, World world) {
        return isIsland(world)
                && !WorldUtil.isInOwnWorld(player)
                && !BypassUtil.bypasses(player);
    }

    private static boolean canModify(Player player, World world) {
        if (BypassUtil.bypasses(player)) return true;
        return WorldUtil.isInOwnWorld(player) && isIsland(world);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;
        if (BypassUtil.bypasses(attacker)) return;

        // PvP remains disabled, but owners must still be able to damage mobs
        // on their own islands. Visitors cannot damage anything on an island.
        if (event.getEntity() instanceof Player) {
            event.setCancelled(true);
            return;
        }

        if (event.getEntity() instanceof LivingEntity
                && isIsland(attacker.getWorld())
                && !WorldUtil.isInOwnWorld(attacker)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Location location = event.getBlock().getLocation();

        if (isProtectedSpawnBlock(location) && !BypassUtil.bypasses(player)) {
            event.setCancelled(true);
            Msg.send(player, "&c⚠ &7You cannot break or change the island spawn blocks.");
            return;
        }

        if (!canModify(player, event.getBlock().getWorld())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        Location location = event.getBlock().getLocation();

        boolean targetProtected = isProtectedSpawnBlock(location);
        boolean clickedProtected = event.getBlockAgainst() != null
                && isProtectedSpawnBlock(event.getBlockAgainst().getLocation());

        if ((targetProtected || clickedProtected) && !BypassUtil.bypasses(player)) {
            event.setCancelled(true);
            Msg.send(player, "&c⚠ &7You cannot place blocks on the island spawn blocks.");
            return;
        }

        if (!canModify(player, event.getBlock().getWorld())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent event) {
        if (isGuest(event.getPlayer(), event.getPlayer().getWorld())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onProjectileLaunch(ProjectileLaunchEvent event) {
        if (!(event.getEntity() instanceof EnderPearl)) return;

        if (event.getEntity().getShooter() instanceof Player player
                && isGuest(player, player.getWorld())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPhysicalInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.PHYSICAL) return;

        Player player = event.getPlayer();

        if (isGuest(player, player.getWorld())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onLiquidFlow(BlockFromToEvent event) {
        // Water/lava may exist on a protected spawn block, but it must never
        // flow into or out of the protected spawn area.
        if (isProtectedSpawnBlock(event.getBlock().getLocation())
                || isProtectedSpawnBlock(event.getToBlock().getLocation())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFallingBlock(EntityChangeBlockEvent event) {
        if (isProtectedSpawnBlock(event.getBlock().getLocation())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent event) {
        if (pistonHitsProtectedSpawn(
                event.getBlock(),
                event.getBlocks(),
                event.getDirection()
        )) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent event) {
        if (pistonHitsProtectedSpawn(
                event.getBlock(),
                event.getBlocks(),
                event.getDirection()
        )) {
            event.setCancelled(true);
        }
    }

    private static boolean pistonHitsProtectedSpawn(
            Block piston,
            List<Block> movedBlocks,
            org.bukkit.block.BlockFace direction
    ) {
        if (!isIsland(piston.getWorld())) return false;

        // The piston head/knob itself must never enter the protected area.
        Location headDestination = piston.getLocation().clone().add(direction.getDirection());
        if (isProtectedSpawnBlock(headDestination)) {
            return true;
        }

        // The piston base must also remain outside the protected area.
        if (isProtectedSpawnBlock(piston.getLocation())) {
            return true;
        }

        for (Block moved : movedBlocks) {
            if (isProtectedSpawnBlock(moved.getLocation())) {
                return true;
            }

            Location destination = moved.getLocation().clone().add(
                    direction.getDirection()
            );

            if (isProtectedSpawnBlock(destination)) {
                return true;
            }
        }

        return false;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (event.getEntity() instanceof Player player
                && isGuest(player, player.getWorld())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();

        if (event.getClickedBlock() != null
                && isGuest(player, event.getClickedBlock().getWorld())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityInteract(PlayerInteractEntityEvent event) {
        Player player = event.getPlayer();

        if (isGuest(player, player.getWorld())) {
            event.setCancelled(true);
        }
    }

    /**
     * Armor stands use their own manipulation event when a player removes or
     * changes their equipment.  PlayerInteractEntityEvent alone is not enough
     * to reliably protect armor stands on guest islands.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onArmorStandManipulate(PlayerArmorStandManipulateEvent event) {
        Player player = event.getPlayer();

        if (isGuest(player, event.getRightClicked().getWorld())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent event) {
        Player player = event.getPlayer();

        if (isGuest(player, player.getWorld())) {
            event.setCancelled(true);
            return;
        }

        // Owners/bypassed players may place water or lava on the spawn blocks.
        // The liquid-flow handler prevents it from spreading afterwards.
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent event) {
        if (isGuest(event.getPlayer(), event.getPlayer().getWorld())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFish(PlayerFishEvent event) {
        Player player = event.getPlayer();

        if (isGuest(player, player.getWorld()) && event.getCaught() != null) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onUnleash(PlayerUnleashEntityEvent event) {
        if (isGuest(event.getPlayer(), event.getPlayer().getWorld())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHangingBreak(HangingBreakByEntityEvent event) {
        if (!(event.getRemover() instanceof Player player)) return;

        if (isGuest(player, player.getWorld())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerPortal(PlayerPortalEvent event) {
        if (isIsland(event.getFrom().getWorld())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityPortal(EntityPortalEvent event) {
        if (isIsland(event.getFrom().getWorld())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPortalCreate(PortalCreateEvent event) {
        if (isIsland(event.getWorld())) {
            event.setCancelled(true);
        }
    }
}