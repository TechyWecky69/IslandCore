package net.islandcore.plugin.listeners;

import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.inventory.ItemStack;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Handles server-wide gameplay restrictions configured in config.yml.
 *
 * Disabled recipes are matched by the material produced by the recipe.
 * For example, adding ENCHANTING_TABLE prevents every recipe that produces
 * an enchanting table from being crafted.
 */
public class GameplayRestrictionListener implements Listener {

    private final boolean withersDisabled;
    private final Set<Material> disabledRecipeResults = new HashSet<>();

    public GameplayRestrictionListener(FileConfiguration config) {
        this.withersDisabled = config.getBoolean("disable-withers", true);

        for (String value : config.getStringList("disabled-recipes")) {
            if (value == null || value.isBlank()) {
                continue;
            }

            try {
                disabledRecipeResults.add(
                        Material.valueOf(value.trim().toUpperCase(Locale.ROOT))
                );
            } catch (IllegalArgumentException ignored) {
                // Ignore invalid config entries instead of stopping the plugin.
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPrepareCraft(PrepareItemCraftEvent event) {
        ItemStack result = event.getInventory().getResult();

        if (isDisabledRecipe(result)) {
            event.getInventory().setResult(null);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCraft(CraftItemEvent event) {
        if (isDisabledRecipe(event.getCurrentItem())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCreatureSpawn(CreatureSpawnEvent event) {
        if (withersDisabled && event.getEntityType() == EntityType.WITHER) {
            event.setCancelled(true);
        }
    }

    private boolean isDisabledRecipe(ItemStack result) {
        return result != null
                && result.getType() != Material.AIR
                && disabledRecipeResults.contains(result.getType());
    }
}
