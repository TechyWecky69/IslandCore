package net.islandcore.plugin.listeners;

import net.islandcore.plugin.ranks.RankManager;
import org.bukkit.plugin.java.JavaPlugin;
import net.islandcore.plugin.util.Msg;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.islandcore.plugin.ranks.Rank;

public class RankListener implements Listener {
    private final RankManager ranks;
    private final JavaPlugin plugin;
    private final Map<UUID, Long> lastChat = new ConcurrentHashMap<>();

    public RankListener(RankManager ranks, JavaPlugin plugin) {
        this.ranks = ranks;
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onJoin(PlayerJoinEvent event) {
        ranks.ensureRank(event.getPlayer());
    }

    /** Chat layout is entirely controlled by chat-prefix in config.yml. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        Rank rank = ranks.getRankOrDefault(player.getUniqueId());
        if (!ranks.hasAtLeast(player.getUniqueId(), Rank.VIP)) {
            long now = System.currentTimeMillis();
            long last = lastChat.getOrDefault(player.getUniqueId(), 0L);
            long remaining = 5000L - (now - last);
            if (remaining > 0) {
                event.setCancelled(true);
                Msg.send(player, "&cPlease wait &e" + ((remaining + 999L) / 1000L) + "s &cbefore chatting again.");
                return;
            }
            lastChat.put(player.getUniqueId(), now);
        }
        String format = plugin.getConfig().getString("chat-prefix");
        if (format == null || format.isEmpty()) {
            event.setCancelled(true);
            plugin.getLogger().warning("Missing or empty 'chat-prefix' in config.yml; chat message was not sent.");
            return;
        }
        event.setFormat(Msg.color(ranks.applyChatFormat(player, format)));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        ranks.remove(event.getPlayer());
        lastChat.remove(event.getPlayer().getUniqueId());
    }
}
