package net.islandcore.plugin.listeners;

import net.islandcore.plugin.managers.MuteManager;
import net.islandcore.plugin.util.Msg;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.entity.Player;

public class MuteListener implements Listener {
    private final MuteManager muteManager;

    public MuteListener(MuteManager muteManager) {
        this.muteManager = muteManager;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        if (!muteManager.isMuted(player.getUniqueId())) return;

        event.setCancelled(true);
        Msg.send(player, "&cYou are muted and cannot chat. &7Reason: &f" + muteManager.getReason(player.getUniqueId()));
    }
}
