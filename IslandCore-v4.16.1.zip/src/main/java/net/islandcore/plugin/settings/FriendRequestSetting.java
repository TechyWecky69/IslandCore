package net.islandcore.plugin.settings;

/** Whether the player accepts incoming friend requests. */
public enum FriendRequestSetting {
    ENABLED,
    DISABLED;

    public FriendRequestSetting next() {
        FriendRequestSetting[] values = values();
        return values[(ordinal() + 1) % values.length];
    }

    public String displayName() {
        return switch (this) {
            case ENABLED  -> "§aEnabled";
            case DISABLED -> "§cDisabled";
        };
    }

    public static FriendRequestSetting fromString(String s) {
        if (s == null) return ENABLED;
        try { return valueOf(s.toUpperCase()); } catch (IllegalArgumentException e) { return ENABLED; }
    }
}
