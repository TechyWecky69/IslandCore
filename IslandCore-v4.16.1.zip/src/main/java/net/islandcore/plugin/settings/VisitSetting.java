package net.islandcore.plugin.settings;

/** Who is allowed to visit the player's island. */
public enum VisitSetting {
    PUBLIC,
    FRIENDS_ONLY,
    DISABLED;

    public VisitSetting next() {
        VisitSetting[] values = values();
        return values[(ordinal() + 1) % values.length];
    }

    public String displayName() {
        return switch (this) {
            case PUBLIC       -> "§aPublic";
            case FRIENDS_ONLY -> "§eFriends Only";
            case DISABLED     -> "§cDisabled";
        };
    }

    public static VisitSetting fromString(String s) {
        if (s == null) return PUBLIC;
        try { return valueOf(s.toUpperCase()); } catch (IllegalArgumentException e) { return PUBLIC; }
    }
}
