package net.islandcore.plugin.settings;

/** Who can send the player private messages. */
public enum MsgSetting {
    PUBLIC,
    FRIENDS_ONLY,
    OFF;

    public MsgSetting next() {
        MsgSetting[] values = values();
        return values[(ordinal() + 1) % values.length];
    }

    public String displayName() {
        return switch (this) {
            case PUBLIC       -> "§aPublic";
            case FRIENDS_ONLY -> "§eFriends Only";
            case OFF          -> "§cOff";
        };
    }

    public static MsgSetting fromString(String s) {
        if (s == null) return PUBLIC;
        try { return valueOf(s.toUpperCase()); } catch (IllegalArgumentException e) { return PUBLIC; }
    }
}
