package net.islandcore.plugin.ranks;

import net.islandcore.plugin.data.DataStore;
import net.islandcore.plugin.ratings.RatingManager;
import net.islandcore.plugin.skilltree.SkillTreeManager;
import net.islandcore.plugin.util.Msg;
import net.islandcore.plugin.util.TeleportCooldownManager;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.permissions.PermissionAttachment;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.*;

public class RankManager {
    private final JavaPlugin plugin;
    private final DataStore data;
    private SkillTreeManager skillTreeManager;
    private RatingManager ratingManager;
    private final Map<UUID, PermissionAttachment> attachments = new HashMap<>();

    public RankManager(JavaPlugin plugin, DataStore data) { this.plugin = plugin; this.data = data; }
    public void setSkillTreeManager(SkillTreeManager manager) { this.skillTreeManager = manager; }
    public void setRatingManager(RatingManager manager) { this.ratingManager = manager; }

    /**
     * Returns the effective ranks after applying the rank cancellation rules:
     * - Member/VIP/MVP/MVP+ form one progression; only the highest is effective.
     * - Beta and Media are independent and are never cancelled.
     * - Helper/Admin/Owner form one staff progression; only the highest is effective.
     */
    public List<Rank> getRanks(UUID uuid) {
        EnumSet<Rank> held = EnumSet.noneOf(Rank.class);
        for (String name : data.getRanks(uuid)) {
            Rank r = Rank.fromName(name);
            if (r != null) held.add(r);
        }
        if (held.isEmpty()) held.add(Rank.MEMBER);

        Rank progression = held.stream()
                .filter(r -> r == Rank.MEMBER || r == Rank.VIP || r == Rank.MVP || r == Rank.MVP_PLUS)
                .max(Comparator.comparingInt(Enum::ordinal)).orElse(null);
        Rank staff = held.stream()
                .filter(r -> r == Rank.HELPER || r == Rank.ADMIN || r == Rank.OWNER)
                .max(Comparator.comparingInt(Enum::ordinal)).orElse(null);

        LinkedHashSet<Rank> effective = new LinkedHashSet<>();
        if (progression != null) effective.add(progression);
        if (held.contains(Rank.BETA)) effective.add(Rank.BETA);
        if (held.contains(Rank.MEDIA)) effective.add(Rank.MEDIA);
        if (staff != null) effective.add(staff);

        return effective.stream()
                .sorted(Comparator.comparingInt(Rank::ordinal).reversed())
                .toList();
    }

    /** Highest effective rank, used for rank benefits that have a single tier. */
    public Rank getRank(UUID uuid) {
        return getRanks(uuid).stream().max(Comparator.comparingInt(Enum::ordinal)).orElse(Rank.MEMBER);
    }
    public Rank getRankOrDefault(UUID uuid) { return getRank(uuid); }

    public Rank getHighestProgressionRank(UUID uuid) {
        return getRanks(uuid).stream()
                .filter(r -> r == Rank.MEMBER || r == Rank.VIP || r == Rank.MVP || r == Rank.MVP_PLUS)
                .max(Comparator.comparingInt(Enum::ordinal)).orElse(Rank.MEMBER);
    }

    public Rank getHighestStaffRank(UUID uuid) {
        return getRanks(uuid).stream()
                .filter(r -> r == Rank.HELPER || r == Rank.ADMIN || r == Rank.OWNER)
                .max(Comparator.comparingInt(Enum::ordinal)).orElse(null);
    }

    /** The rank currently chosen for display in chat/tab/nametag. */
    public Rank getDisplayRank(UUID uuid) {
        String selected = data.getRank(uuid);
        Rank r = Rank.fromName(selected);
        return r != null && getRanks(uuid).contains(r) ? r : getRanks(uuid).get(0);
    }

    public void setDisplayRank(UUID uuid, Rank rank) {
        List<Rank> heldRanks = getRanks(uuid);
        if (!heldRanks.contains(rank)) return;
        List<String> held = heldRanks.stream().map(r -> r.name().toLowerCase()).toList();
        // Preserve all held ranks in the list; the legacy rank field stores the selected display rank.
        data.setRanksPreservingList(uuid, held, rank.name().toLowerCase());
        Player player = plugin.getServer().getPlayer(uuid);
        if (player != null) { setPrefix(player, getDisplayRank(uuid)); updateTabName(player); }
    }

    public void ensureRank(Player player) {
        data.ensurePlayer(player.getUniqueId());
        if (data.getRanks(player.getUniqueId()).isEmpty()) {
            data.setRanks(player.getUniqueId(), List.of(Rank.MEMBER.name().toLowerCase()), false);
        }
        apply(player); updateTabName(player); setPrefix(player, getDisplayRank(player.getUniqueId()));
        TeleportCooldownManager.configureForRank(player.getUniqueId(), getHighestProgressionRank(player.getUniqueId()));
    }

    public void addRank(UUID uuid, Rank rank) {
        List<String> ranks = new ArrayList<>(data.getRanks(uuid));
        if (!ranks.stream().anyMatch(s -> Rank.fromName(s) == rank)) {
            ranks.add(rank.name().toLowerCase());
            String active = data.getRank(uuid);
            if (active == null || Rank.fromName(active) == null) active = rank.name().toLowerCase();
            data.setRanksPreservingList(uuid, ranks, active);
        }
        refresh(uuid);
    }

    public void removeRank(UUID uuid, Rank rank) {
        List<String> ranks = new ArrayList<>(data.getRanks(uuid));
        ranks.removeIf(s -> Rank.fromName(s) == rank);
        if (ranks.isEmpty()) ranks.add(Rank.MEMBER.name().toLowerCase());
        String active = data.getRank(uuid);
        String finalActive = active;
        if (Rank.fromName(active) == rank || !ranks.stream().anyMatch(s -> Rank.fromName(s) == Rank.fromName(finalActive))) {
            active = getBestDisplayRankFromHeld(ranks).name().toLowerCase();
        }
        data.setRanksPreservingList(uuid, ranks, active);
        refresh(uuid);
    }

    private Rank getBestDisplayRankFromHeld(List<String> stored) {
        return stored.stream().map(Rank::fromName).filter(Objects::nonNull)
                .max(Comparator.comparingInt(Enum::ordinal)).orElse(Rank.MEMBER);
    }
    private void refresh(UUID uuid) {
        Player player = plugin.getServer().getPlayer(uuid);
        if (player != null) { apply(player); updateTabName(player); setPrefix(player, getDisplayRank(uuid)); TeleportCooldownManager.configureForRank(uuid, getHighestProgressionRank(uuid)); }
    }

    public void setPrefix(Player player, Rank rank) {
        Scoreboard scoreboard = player.getScoreboard();
        if (scoreboard == null) return;
        for (Rank existing : Rank.values()) { Team t = scoreboard.getTeam(existing.name()); if (t != null) t.removeEntry(player.getName()); }
        Team team = scoreboard.getTeam(rank.name());
        if (team == null) team = scoreboard.registerNewTeam(rank.name());
        String symbol = skillTreeManager != null ? skillTreeManager.getActiveSymbol(player.getUniqueId()) : "";
        team.setPrefix(Msg.color(rank.getPrefix() + " &f" + symbol + " "));
        team.addEntry(player.getName());
    }

    public void apply(Player player) {
        PermissionAttachment old = attachments.remove(player.getUniqueId());
        if (old != null) player.removeAttachment(old);
        Rank rank = getRankOrDefault(player.getUniqueId());
        PermissionAttachment attachment = player.addAttachment(plugin);
        for (String permission : Rank.ALL_PERMISSIONS) attachment.setPermission(permission, false);
        for (Rank r : getRanks(player.getUniqueId())) for (String permission : r.getPermissions()) attachment.setPermission(permission, true);
        // Base permissions for every rank.
        for (String permission : List.of("islandcore.visit", "islandcore.home", "islandcore.setspawn", "islandcore.myisland", "islandcore.msg", "islandcore.reply", "islandcore.rate", "islandcore.topislands", "islandcore.report", "islandcore.reportisland", "islandcore.friend", "islandcore.block", "islandcore.trade", "islandcore.myrank", "islandcore.toggle", "islandcore.toggleislandvisits", "islandcore.progressiontree")) attachment.setPermission(permission, true);
        if (player.isOp()) for (String permission : Rank.ALL_PERMISSIONS) attachment.setPermission(permission, true);
        attachments.put(player.getUniqueId(), attachment);
        plugin.getServer().getScheduler().runTask(plugin, player::updateCommands);
    }

    public void updateTabName(Player player) {
        Rank rank = getDisplayRank(player.getUniqueId());
        String symbol = skillTreeManager != null ? skillTreeManager.getActiveSymbol(player.getUniqueId()) + " " : "";
        String ownerBadge = ratingManager != null ? ratingManager.ownerStarBadge(player.getUniqueId()) : "";
        player.setPlayerListName(Msg.color(rank.getPrefix() + " " + symbol + "&f" + player.getName() + ownerBadge));
    }
    /**
     * Expands the configurable chat-prefix template for a player.
     * The template itself lives exclusively in config.yml.
     */
    public String applyChatFormat(Player player, String template) {
        UUID uuid = player.getUniqueId();
        Rank rank = getDisplayRank(uuid);
        String rankPrefix = rank.getPrefix();
        String rankNameColor = rank.getNameColor();
        String name = player.getName();
        String nameColoured = rankNameColor + name;
        int level = plugin instanceof net.islandcore.plugin.IslandCorePlugin
                ? ((net.islandcore.plugin.IslandCorePlugin) plugin).getLevelManager().getLevel(uuid)
                : 0;

        String nodeSymbol = "";
        String nodeSymbolColor = "";
        String nodeName = "";
        String nodeNameColor = "";
        if (skillTreeManager != null) {
            nodeSymbol = skillTreeManager.getActiveSymbolPlain(uuid);
            nodeSymbolColor = skillTreeManager.getActiveSymbol(uuid);
            nodeName = skillTreeManager.getActiveNodeName(uuid);
            nodeNameColor = skillTreeManager.getActiveNodeNameColor(uuid);
        }

        return template
                .replace("%RANK%", rankPrefix)
                .replace("%LEVEL%", String.valueOf(level))
                .replace("%NODE_SYMBOL_COLOR%", nodeSymbolColor)
                .replace("%NODE_SYMBOL%", nodeSymbol)
                .replace("%NODE_NAME%", nodeName)
                .replace("%NODE_NAME_COLOR%", nodeNameColor)
                .replace("%NAME%", name)
                .replace("%NAME_COLOURED%", nameColoured)
                .replace("%MESSAGE%", "%2$s")
                .replace("%PLAYER%", "%1$s");
    }

    public String getChatPrefix(UUID uuid) { return getDisplayRank(uuid).getPrefix(); }

    public void remove(Player player) { PermissionAttachment a = attachments.remove(player.getUniqueId()); if (a != null) player.removeAttachment(a); }
    public void removeAll() { for (Player p : plugin.getServer().getOnlinePlayers()) remove(p); }

    public boolean hasAtLeast(UUID uuid, Rank rank) {
        if (rank == Rank.MEMBER || rank == Rank.VIP || rank == Rank.MVP || rank == Rank.MVP_PLUS) {
            return getHighestProgressionRank(uuid).atLeast(rank);
        }
        if (rank == Rank.HELPER || rank == Rank.ADMIN || rank == Rank.OWNER) {
            Rank staff = getHighestStaffRank(uuid);
            return staff != null && staff.atLeast(rank);
        }
        return getRanks(uuid).contains(rank);
    }
}
