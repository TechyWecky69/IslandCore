package net.islandcore.plugin.friends;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.logging.Level;

/**
 * Persistent block lists.
 *
 * If player A blocks player B:
 *  - B cannot visit A's island.
 *  - A cannot see messages sent by B (and vice-versa; blocking is silently
 *    mutual for messaging).
 *  - Any existing friendship between A and B is severed when the block is
 *    placed (handled by BlockCommand via FriendManager).
 *
 * Blocks are one-directional in storage: "A blocked B" is only stored on A's
 * list.  Use {@link #isBlocked(UUID, UUID)} to check either direction.
 */
public class BlockManager {

    private final JavaPlugin plugin;
    private final File file;
    private FileConfiguration config;

    /** blockerUuid -> set of UUIDs that player has blocked */
    private final Map<UUID, Set<UUID>> blocked = new HashMap<>();

    public BlockManager(JavaPlugin plugin) {
        this.plugin = plugin;
        File dataDir = new File(plugin.getDataFolder(), "data");
        if (!dataDir.exists()) dataDir.mkdirs();
        this.file = new File(dataDir, "blocks.yml");
        load();
    }

    // ── Persistence ──────────────────────────────────────────────────────────

    private void load() {
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().log(Level.SEVERE, "Could not create data/blocks.yml", e);
            }
        }
        config = YamlConfiguration.loadConfiguration(file);

        ConfigurationSection section = config.getConfigurationSection("blocks");
        if (section == null) return;

        for (String key : section.getKeys(false)) {
            UUID blocker = parse(key);
            if (blocker == null) continue;

            Set<UUID> targets = new HashSet<>();
            for (String raw : section.getStringList(key)) {
                UUID uuid = parse(raw);
                if (uuid != null) targets.add(uuid);
            }
            blocked.put(blocker, targets);
        }
    }

    public synchronized void save() {
        config.set("blocks", null);

        for (Map.Entry<UUID, Set<UUID>> entry : blocked.entrySet()) {
            if (entry.getValue().isEmpty()) continue;
            List<String> values = new ArrayList<>();
            for (UUID uuid : entry.getValue()) values.add(uuid.toString());
            config.set("blocks." + entry.getKey(), values);
        }

        try {
            config.save(file);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Could not save data/blocks.yml", e);
        }
    }

    // ── API ───────────────────────────────────────────────────────────────────

    /**
     * Returns true if {@code a} has blocked {@code b} OR {@code b} has blocked
     * {@code a}.  Either direction counts as a block for messaging purposes.
     */
    public boolean isBlocked(UUID a, UUID b) {
        return hasBlocked(a, b) || hasBlocked(b, a);
    }

    /** Returns true only if {@code blocker} has explicitly blocked {@code target}. */
    public boolean hasBlocked(UUID blocker, UUID target) {
        return blocked.getOrDefault(blocker, Set.of()).contains(target);
    }

    /** {@code blocker} blocks {@code target}.  Idempotent. */
    public void block(UUID blocker, UUID target) {
        blocked.computeIfAbsent(blocker, k -> new HashSet<>()).add(target);
        save();
    }

    /**
     * {@code blocker} unblocks {@code target}.
     *
     * @return true if the block existed and was removed; false if there was
     *         nothing to remove.
     */
    public boolean unblock(UUID blocker, UUID target) {
        Set<UUID> set = blocked.get(blocker);
        if (set == null || !set.remove(target)) return false;
        save();
        return true;
    }

    /** Returns an unmodifiable view of everyone that {@code blocker} has blocked. */
    public Set<UUID> getBlockedBy(UUID blocker) {
        return Collections.unmodifiableSet(blocked.getOrDefault(blocker, Set.of()));
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private UUID parse(String raw) {
        try {
            return UUID.fromString(raw);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
