package net.islandcore.plugin.managers;

import net.islandcore.plugin.data.DataStore;
import net.islandcore.plugin.util.Msg;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Handles player levels, XP and persistent playtime tracking. */
public class LevelManager implements Listener {
    public record XpResult(int levelsGained, int level, int xp) {}

    private final JavaPlugin plugin;
    private final DataStore data;
    private final Map<UUID, Long> sessionStart = new HashMap<>();

    public LevelManager(JavaPlugin plugin, DataStore data) {
        this.plugin = plugin;
        this.data = data;
    }

    public int getLevel(UUID uuid) { return data.getLevel(uuid); }
    public int getXp(UUID uuid) { return data.getXp(uuid); }
    public long getTotalXp(UUID uuid) { return data.getTotalXp(uuid); }
    public long getPlaytimeSeconds(UUID uuid) { return data.getPlaytimeSeconds(uuid); }

    public XpResult addXp(UUID uuid, int amount) {
        if (amount <= 0) return new XpResult(0, getLevel(uuid), getXp(uuid));
        int before = data.getLevel(uuid);
        data.addXp(uuid, amount);
        int after = data.getLevel(uuid);
        int gained = after - before;
        if (gained > 0) {
            Player player = Bukkit.getPlayer(uuid);
            if (player != null) {
                Msg.send(player, "&a&lLEVEL UP! &7You are now &eLevel " + after + "&7!");
            }
        }
        return new XpResult(gained, after, data.getXp(uuid));
    }

    public void startTracking(UUID uuid) {
        sessionStart.putIfAbsent(uuid, System.currentTimeMillis());
    }

    public void stopTracking(UUID uuid) {
        flushPlaytime(uuid, true);
        sessionStart.remove(uuid);
    }

    /** Saves the current session's playtime and awards hourly XP up to 100 hours. */
    public synchronized long flushPlaytime(UUID uuid, boolean save) {
        Long start = sessionStart.get(uuid);
        if (start == null) {
            if (Bukkit.getPlayer(uuid) != null) startTracking(uuid);
            return 0L;
        }
        long now = System.currentTimeMillis();
        long elapsed = Math.max(0L, (now - start) / 1000L);
        if (elapsed <= 0) return 0L;

        long oldTotal = data.getPlaytimeSeconds(uuid);
        long newTotal = oldTotal + elapsed;
        data.addPlaytimeSeconds(uuid, elapsed);
        sessionStart.put(uuid, now - ((now - start) % 1000L));

        long oldAwardedHours = Math.min(100L, oldTotal / 3600L);
        long newAwardedHours = Math.min(100L, newTotal / 3600L);
        long hoursCrossed = Math.max(0L, newAwardedHours - oldAwardedHours);
        if (hoursCrossed > 0) addXp(uuid, (int) hoursCrossed * 10);

        if (save) data.save();
        return elapsed;
    }

    public void resetTracking(UUID uuid) {
        sessionStart.remove(uuid);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        stopTracking(event.getPlayer().getUniqueId());
    }

    public void startOnlinePlayers() {
        for (Player player : Bukkit.getOnlinePlayers()) startTracking(player.getUniqueId());
    }

    public void flushOnlinePlayers() {
        for (Player player : Bukkit.getOnlinePlayers()) flushPlaytime(player.getUniqueId(), false);
    }

    public void saveOnlinePlaytime() {
        flushOnlinePlayers();
        data.save();
    }

    public static String formatPlaytime(long seconds) {
        long hours = seconds / 3600L;
        long minutes = (seconds % 3600L) / 60L;
        long secs = seconds % 60L;
        if (hours > 0) return hours + "h " + minutes + "m";
        if (minutes > 0) return minutes + "m " + secs + "s";
        return secs + "s";
    }
}
