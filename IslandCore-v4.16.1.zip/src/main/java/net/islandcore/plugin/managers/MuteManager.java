package net.islandcore.plugin.managers;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

public class MuteManager {
    private final JavaPlugin plugin;
    private final File file;
    private final FileConfiguration config;

    public MuteManager(JavaPlugin plugin) {
        this.plugin = plugin;
        if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
        this.file = new File(plugin.getDataFolder(), "mutes.yml");
        this.config = YamlConfiguration.loadConfiguration(file);
        cleanupExpired();
    }

    public void mute(UUID uuid, String reason, long expiresAt, String source) {
        String path = uuid.toString();
        config.set(path + ".reason", reason);
        config.set(path + ".expiresAt", expiresAt);
        config.set(path + ".source", source);
        save();
    }

    public void unmute(UUID uuid) {
        config.set(uuid.toString(), null);
        save();
    }

    public boolean isMuted(UUID uuid) {
        String path = uuid.toString();
        if (!config.contains(path)) return false;
        long expiresAt = config.getLong(path + ".expiresAt", 0L);
        if (expiresAt > 0 && System.currentTimeMillis() >= expiresAt) {
            unmute(uuid);
            return false;
        }
        return true;
    }

    public String getReason(UUID uuid) {
        return config.getString(uuid.toString() + ".reason", "No reason specified.");
    }

    public long getExpiresAt(UUID uuid) {
        return config.getLong(uuid.toString() + ".expiresAt", 0L);
    }

    private void cleanupExpired() {
        boolean changed = false;
        for (String key : config.getKeys(false)) {
            long expiresAt = config.getLong(key + ".expiresAt", 0L);
            if (expiresAt > 0 && System.currentTimeMillis() >= expiresAt) {
                config.set(key, null);
                changed = true;
            }
        }
        if (changed) save();
    }

    private void save() {
        try {
            config.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save mutes.yml: " + e.getMessage());
        }
    }
}
