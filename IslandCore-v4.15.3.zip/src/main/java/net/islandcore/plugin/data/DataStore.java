package net.islandcore.plugin.data;

import net.islandcore.plugin.settings.FriendRequestSetting;
import net.islandcore.plugin.settings.MsgSetting;
import net.islandcore.plugin.settings.VisitSetting;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Persistent player data.
 *
 * Each player's data is stored under their UUID so playerdata.yml stays
 * grouped by player instead of being split across several top-level sections.
 *
 * Example:
 *
 * uuid:
 *   rank: member
 *   ranks:
 *     - member
 *   visitable: false
 *   game-status: false
 *   loot-pulls: 0
 *   worldname: Steve's world
 *   island-time: 234
 */
public class DataStore {
    private final JavaPlugin plugin;
    private final File file;
    private FileConfiguration config;

    public DataStore(JavaPlugin plugin) {
        this.plugin = plugin;

        File dataDir = new File(plugin.getDataFolder(), "data");
        if (!dataDir.exists()) dataDir.mkdirs();

        this.file = new File(dataDir, "playerdata.yml");
        migrateLegacyFile();
        load();
        migratePlayerDataLayout();
    }

    private void migrateLegacyFile() {
        File legacy = new File(plugin.getDataFolder(), "playerdata.yml");
        if (!file.exists() && legacy.exists()) {
            try {
                if (legacy.renameTo(file)) {
                    plugin.getLogger().info("Migrated playerdata.yml to data/playerdata.yml.");
                }
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Could not migrate legacy playerdata.yml", e);
            }
        }
    }

    private void load() {
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().log(Level.SEVERE, "Could not create data/playerdata.yml", e);
            }
        }

        config = YamlConfiguration.loadConfiguration(file);
    }

    /**
     * Converts the old split layout:
     *
     * ranks:
     *   uuid:
     *     rank: member
     *     list:
     *       - member
     * islands:
     *   uuid:
     *     visitable: false
     * game:
     *   uuid:
     *     status: false
     *     loot-pulls: 300
     * worldnames:
     *   uuid: world
     * island-time:
     *   uuid:
     *     full-time: 234
     *
     * into one section per player.
     */
    private void migratePlayerDataLayout() {
        boolean changed = false;

        changed |= migrateSection("ranks", (uuid, old) -> {
            copyIfMissing(uuid, "rank", old.getString("rank"));
            List<String> ranks = old.getStringList("list");
            if (ranks.isEmpty()) {
                String rank = old.getString("rank");
                if (rank != null && !rank.isBlank()) {
                    ranks = List.of(rank);
                }
            }
            if (!ranks.isEmpty()) copyIfMissing(uuid, "ranks", new ArrayList<>(ranks));
        });

        changed |= migrateSection("islands", (uuid, old) ->
                copyIfMissing(uuid, "visitable", old.getBoolean("visitable", false)));

        changed |= migrateSection("game", (uuid, old) -> {
            copyIfMissing(uuid, "game-status", old.getBoolean("status", false));
            copyIfMissing(uuid, "loot-pulls", old.getInt("loot-pulls", 0));
        });

        ConfigurationSection worldNames = config.getConfigurationSection("worldnames");
        if (worldNames != null) {
            for (String key : worldNames.getKeys(false)) {
                UUID uuid = parseUuid(key);
                if (uuid == null) continue;
                copyIfMissing(uuid, "worldname", worldNames.get(key));
                changed = true;
            }
            config.set("worldnames", null);
        }

        ConfigurationSection islandTimes = config.getConfigurationSection("island-time");
        if (islandTimes != null) {
            for (String key : islandTimes.getKeys(false)) {
                UUID uuid = parseUuid(key);
                if (uuid == null) continue;

                Object value = islandTimes.get(key + ".full-time");
                if (value != null) {
                    copyIfMissing(uuid, "island-time", value);
                    changed = true;
                }
            }
            config.set("island-time", null);
        }

        // Ensure migrated players have the new standard fields where possible.
        for (String key : new ArrayList<>(config.getKeys(false))) {
            UUID uuid = parseUuid(key);
            if (uuid == null) continue;
            ensurePlayerFields(uuid, false);
        }

        if (changed) {
            save();
            plugin.getLogger().info("Migrated playerdata.yml to the per-player UUID layout.");
        }
    }

    private boolean migrateSection(String sectionName, PlayerSectionMigrator migrator) {
        ConfigurationSection section = config.getConfigurationSection(sectionName);
        if (section == null) return false;

        boolean foundPlayer = false;

        for (String key : section.getKeys(false)) {
            UUID uuid = parseUuid(key);
            if (uuid == null) continue;

            ConfigurationSection old = section.getConfigurationSection(key);
            if (old == null) continue;

            migrator.migrate(uuid, old);
            foundPlayer = true;
        }

        config.set(sectionName, null);
        return foundPlayer;
    }

    private void copyIfMissing(UUID uuid, String field, Object value) {
        if (value == null) return;

        String path = path(uuid, field);
        if (!config.contains(path)) {
            config.set(path, value);
        }
    }

    private UUID parseUuid(String value) {
        try {
            return UUID.fromString(value);
        } catch (IllegalArgumentException ignored) {
            return null;
        }
    }

    private String path(UUID uuid, String field) {
        return uuid + "." + field;
    }

    private void ensurePlayerFields(UUID uuid, boolean save) {
        boolean changed = false;

        String rankPath = path(uuid, "rank");
        String ranksPath = path(uuid, "ranks");

        if (!config.contains(rankPath)) {
            config.set(rankPath, "member");
            changed = true;
        }

        if (!config.contains(ranksPath)) {
            String rank = config.getString(rankPath, "member");
            config.set(ranksPath, new ArrayList<>(List.of(rank)));
            changed = true;
        }

        if (!config.contains(path(uuid, "visitable"))) {
            config.set(path(uuid, "visitable"), false);
            changed = true;
        }

        if (!config.contains(path(uuid, "visit-setting"))) {
            config.set(path(uuid, "visit-setting"), VisitSetting.PUBLIC.name());
            changed = true;
        }

        if (!config.contains(path(uuid, "msg-setting"))) {
            config.set(path(uuid, "msg-setting"), MsgSetting.PUBLIC.name());
            changed = true;
        }

        if (!config.contains(path(uuid, "friend-request-setting"))) {
            config.set(path(uuid, "friend-request-setting"), FriendRequestSetting.ENABLED.name());
            changed = true;
        }

        if (!config.contains(path(uuid, "game-status"))) {
            config.set(path(uuid, "game-status"), false);
            changed = true;
        }

        if (!config.contains(path(uuid, "loot-pulls"))) {
            config.set(path(uuid, "loot-pulls"), 0);
            changed = true;
        }

        if (save && changed) save();
    }

    /**
     * Ensures a player has a complete playerdata entry.
     * Called when the player joins.
     */
    public void ensurePlayer(UUID uuid) {
        ensurePlayerFields(uuid, true);
    }

    public synchronized void save() {
        try {
            config.save(file);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Could not save data/playerdata.yml", e);
        }
    }

    public String getRank(UUID uuid) {
        return config.getString(path(uuid, "rank"));
    }

    /** Returns all ranks held by a player. */
    public List<String> getRanks(UUID uuid) {
        List<String> stored = config.getStringList(path(uuid, "ranks"));
        if (!stored.isEmpty()) return new ArrayList<>(stored);

        String rank = getRank(uuid);
        if (rank == null || rank.isBlank()) return new ArrayList<>();

        return new ArrayList<>(List.of(rank));
    }

    public void setRanks(UUID uuid, List<String> ranks) {
        setRanks(uuid, ranks, true);
    }

    public void setRanks(UUID uuid, List<String> ranks, boolean save) {
        config.set(path(uuid, "ranks"), new ArrayList<>(ranks));
        config.set(path(uuid, "rank"), ranks.isEmpty() ? "member" : ranks.get(0));
        if (save) save();
    }

    /** Stores the held-rank list and a separate active/display rank. */
    public void setRanksPreservingList(UUID uuid, List<String> ranks, String activeRank) {
        config.set(path(uuid, "ranks"), new ArrayList<>(ranks));
        config.set(path(uuid, "rank"), activeRank);
        save();
    }

    public void setRank(UUID uuid, String rank) {
        setRank(uuid, rank, true);
    }

    public void setRank(UUID uuid, String rank, boolean save) {
        setRanks(uuid, List.of(rank), save);
    }

    public boolean isVisitable(UUID uuid) {
        return config.getBoolean(path(uuid, "visitable"), false);
    }

    public void setVisitable(UUID uuid, boolean visitable) {
        config.set(path(uuid, "visitable"), visitable);
        save();
    }

    // ── Settings GUI fields ───────────────────────────────────────────────────

    public VisitSetting getVisitSetting(UUID uuid) {
        return VisitSetting.fromString(config.getString(path(uuid, "visit-setting")));
    }

    public void setVisitSetting(UUID uuid, VisitSetting setting) {
        config.set(path(uuid, "visit-setting"), setting.name());
        // Keep the legacy boolean in sync so any code that still reads isVisitable() works correctly.
        config.set(path(uuid, "visitable"), setting == VisitSetting.PUBLIC);
        save();
    }

    public MsgSetting getMsgSetting(UUID uuid) {
        return MsgSetting.fromString(config.getString(path(uuid, "msg-setting")));
    }

    public void setMsgSetting(UUID uuid, MsgSetting setting) {
        config.set(path(uuid, "msg-setting"), setting.name());
        save();
    }

    public FriendRequestSetting getFriendRequestSetting(UUID uuid) {
        return FriendRequestSetting.fromString(config.getString(path(uuid, "friend-request-setting")));
    }

    public void setFriendRequestSetting(UUID uuid, FriendRequestSetting setting) {
        config.set(path(uuid, "friend-request-setting"), setting.name());
        save();
    }

    public boolean isLootingActive(UUID uuid) {
        return config.getBoolean(path(uuid, "game-status"), false);
    }

    public void setLootingActive(UUID uuid, boolean active) {
        config.set(path(uuid, "game-status"), active);
        save();
    }

    /** Number of successful random-pull item rewards received by the player. */
    public int getLootPulls(UUID uuid) {
        return config.getInt(path(uuid, "loot-pulls"), 0);
    }

    /** Increments the player's successful random-pull count and returns the new total. */
    public synchronized int incrementLootPulls(UUID uuid) {
        int pulls = getLootPulls(uuid) + 1;
        config.set(path(uuid, "loot-pulls"), pulls);
        return pulls;
    }

    public void setWorldName(UUID uuid, String worldName) {
        config.set(path(uuid, "worldname"), worldName);
        save();
    }

    public String getWorldName(UUID uuid) {
        return config.getString(path(uuid, "worldname"));
    }

    /** Persist the exact Minecraft time of an island world. */
    public long getIslandFullTime(UUID uuid) {
        return config.getLong(path(uuid, "island-time"), Long.MIN_VALUE);
    }

    public void setIslandFullTime(UUID uuid, long fullTime, boolean save) {
        config.set(path(uuid, "island-time"), fullTime);
        if (save) save();
    }

    /**
     * Wipes everything tied to a player's island.
     * Rank data is left untouched - a reset is not a demotion.
     */
    public synchronized void resetPlayer(UUID uuid) {
        config.set(path(uuid, "visitable"), false);
        config.set(path(uuid, "game-status"), false);
        config.set(path(uuid, "loot-pulls"), 0);
        config.set(path(uuid, "worldname"), null);
        config.set(path(uuid, "island-time"), null);
        save();
    }

    @FunctionalInterface
    private interface PlayerSectionMigrator {
        void migrate(UUID uuid, ConfigurationSection old);
    }
}
