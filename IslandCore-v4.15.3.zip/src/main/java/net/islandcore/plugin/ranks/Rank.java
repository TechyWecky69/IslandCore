package net.islandcore.plugin.ranks;

import java.util.List;

/** All player ranks, ordered from lowest to highest for permission inheritance. */
public enum Rank {
    MEMBER("&7[&8Member&7]", "&7", List.of()),
    VIP("&a[VIP]", "&a", List.of()),
    MVP("&b[MVP]", "&b", List.of()),
    MVP_PLUS("&6[MVP&f+&6]", "&6", List.of()),
    BETA("&e[Beta]", "&e", List.of()),
    MEDIA("&5[Media]", "&5", List.of()),
    HELPER("&c[Helper]", "&c", List.of("islandcore.kick", "islandcore.invsee", "islandcore.enderchest", "islandcore.stafftp", "islandcore.viewtree", "islandcore.mute")),
    ADMIN("&4[Admin]", "&4", List.of("islandcore.kick", "islandcore.invsee", "islandcore.enderchest", "islandcore.stafftp", "islandcore.viewtree", "islandcore.ban", "islandcore.unban", "islandcore.mute", "islandcore.bypass", "islandcore.tokens.spawn", "islandcore.resetratings")),
    OWNER("&d[Owner]", "&d", List.of("islandcore.kick", "islandcore.invsee", "islandcore.enderchest", "islandcore.stafftp", "islandcore.viewtree", "islandcore.ban", "islandcore.unban", "islandcore.mute", "islandcore.bypass", "islandcore.rank.manage", "islandcore.tokens.spawn", "islandcore.resetplayer", "islandcore.resetratings", "islandcore.ownerrate"));

    public static final List<String> ALL_PERMISSIONS = List.of(
            "islandcore.visit", "islandcore.home", "islandcore.setspawn", "islandcore.myisland", "islandcore.msg",
            "islandcore.reply", "islandcore.rate", "islandcore.topislands", "islandcore.report", "islandcore.reportisland", "islandcore.friend", "islandcore.block", "islandcore.trade", "islandcore.myrank", "islandcore.toggle", "islandcore.toggleislandvisits",
            "islandcore.invsee", "islandcore.enderchest", "islandcore.stafftp", "islandcore.kick", "islandcore.ban", "islandcore.unban", "islandcore.mute",
            "islandcore.bypass", "islandcore.rank.manage", "islandcore.skilltree", "islandcore.viewtree", "islandcore.tokens.spawn", "islandcore.resetplayer",
            "islandcore.resetratings", "islandcore.ownerrate"
    );

    private final String prefix;
    private final String nameColor;
    private final List<String> permissions;

    Rank(String prefix, String nameColor, List<String> permissions) {
        this.prefix = prefix;
        this.nameColor = nameColor;
        this.permissions = permissions;
    }

    public String getPrefix() { return prefix; }
    public String getNameColor() { return nameColor; }
    public List<String> getPermissions() { return permissions; }

    public boolean atLeast(Rank other) { return ordinal() >= other.ordinal(); }

    public static Rank fromName(String name) {
        for (Rank rank : values()) if (rank.name().equalsIgnoreCase(name) || rank.name().replace('_', '+').equalsIgnoreCase(name)) return rank;
        return null;
    }
}
