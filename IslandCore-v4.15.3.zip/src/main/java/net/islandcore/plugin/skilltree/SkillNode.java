package net.islandcore.plugin.skilltree;

import net.islandcore.plugin.util.Colors;
import net.islandcore.plugin.util.Msg;
import net.islandcore.plugin.util.Symbols;
import org.bukkit.Material;

import java.util.List;

/** One unlockable node in the visual Progression Tree. */
public class SkillNode {

    public enum Rarity { COMMON, UNCOMMON, RARE }

    private final String id;
    private final String displayName;
    private final Material icon;
    private final String[] description;
    private final String category;
    private final int tokenCost;
    private final List<ItemCost> itemCosts;
    private final int guiSlot;

    public SkillNode(String id, String displayName, Material icon, String[] description,
                     String category, int tokenCost, List<ItemCost> itemCosts, int guiSlot) {
        this.id = id;
        this.displayName = displayName;
        this.icon = icon;
        this.description = description;
        this.category = category;
        this.tokenCost = tokenCost;
        this.itemCosts = itemCosts;
        this.guiSlot = guiSlot;
    }

    public String getId() { return id; }
    public String getDisplayName() { return displayName; }
    public Material getIcon() { return icon; }
    public String[] getDescription() { return description; }
    public String getCategory() { return category; }
    public int getTokenCost() { return tokenCost; }
    public List<ItemCost> getItemCosts() { return itemCosts; }
    public int getGuiSlot() { return guiSlot; }

    public String getColoredSymbol() {
        String id = this.id;
        if (id.startsWith("mining1")) return Colors.BRONZE + Symbols.MINING;
        if (id.startsWith("mining2")) return Colors.SILVER + Symbols.MINING;
        if (id.startsWith("mining3")) return Colors.GOLD + Symbols.MINING;
        if (id.startsWith("farming1")) return Colors.BRONZE + Symbols.FARM;
        if (id.startsWith("farming2")) return Colors.SILVER + Symbols.FARM;
        if (id.startsWith("farming3")) return Colors.GOLD + Symbols.FARM;
        if (id.equals("nether1")) return Colors.SILVER + Symbols.NETHER;
        if (id.equals("nether2")) return Colors.GOLD + Symbols.NETHER;
        if (id.equals("end1")) return Colors.SILVER + Symbols.END;
        if (id.equals("end2")) return Colors.GOLD + Symbols.END;
        if (id.equals("enchanting1")) return Colors.BRONZE + Symbols.ENCHANTING;
        if (id.equals("enchanting2")) return Colors.SILVER + Symbols.ENCHANTING;
        if (id.equals("enchanting3")) return Colors.GOLD + Symbols.ENCHANTING;
        if (id.equals("brewing")) return Colors.GOLD + Symbols.ALCHEMY;
        if (id.equals("fishing")) return Colors.GOLD + Symbols.FISHING;
        if (id.equals("biome")) return Colors.GOLD + Symbols.BIOME;
        if (id.equals("colour")) return Colors.GOLD + Msg.color("&l") + Symbols.COLOUR;
        if (id.equals("flowers1")) return Colors.SILVER + Msg.color("&l") + Symbols.FLOWER;
        if (id.equals("flowers2")) return Colors.GOLD + Msg.color("&l") + Symbols.FLOWER;
        return Symbols.SKILL_TREE;
    }

    public static class LootEntry {
        private final Material material;
        private final Rarity rarity;
        public LootEntry(Material material, Rarity rarity) { this.material = material; this.rarity = rarity; }
        public Material getMaterial() { return material; }
        public Rarity getRarity() { return rarity; }
        public int getWeight() {
            return switch (rarity) { case COMMON -> 60; case UNCOMMON -> 30; case RARE -> 10; };
        }
    }

    public static class ItemCost {
        private final Material material;
        private final int amount;
        public ItemCost(Material material, int amount) { this.material = material; this.amount = amount; }
        public Material getMaterial() { return material; }
        public int getAmount() { return amount; }
    }
}
