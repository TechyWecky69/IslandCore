package com.blockbound.islandcoresocials.commands;

import com.blockbound.islandcoresocials.IslandCoreSocials;
import com.blockbound.islandcoresocials.gui.SocialsGui;
import com.blockbound.islandcoresocials.models.PlayerSocials;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SocialCommand implements CommandExecutor {

    private final IslandCoreSocials plugin;

    public SocialCommand(IslandCoreSocials plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command,
                             String label, String[] args) {

        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        if (!player.hasPermission("islandcoresocials.social")) {
            player.sendMessage(plugin.msg("no-permission"));
            return true;
        }

        if (args.length == 0) {
            // Own profile — editable
            PlayerSocials ps = plugin.getSocialDataManager()
                    .get(player.getUniqueId(), player.getName());
            SocialsGui.open(plugin, player, ps, true);

        } else {
            // Another player — read-only
            String targetName = args[0];
            Player online = Bukkit.getPlayerExact(targetName);

            if (online != null) {
                PlayerSocials ps = plugin.getSocialDataManager()
                        .get(online.getUniqueId(), online.getName());
                SocialsGui.open(plugin, player, ps, false);
            } else {
                // Try offline lookup
                plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
                    PlayerSocials ps = plugin.getSocialDataManager().getByName(targetName);
                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        if (ps == null) {
                            player.sendMessage(plugin.msg("social-not-found",
                                    "{player}", targetName));
                        } else {
                            SocialsGui.open(plugin, player, ps, false);
                        }
                    });
                });
            }
        }

        return true;
    }
}
