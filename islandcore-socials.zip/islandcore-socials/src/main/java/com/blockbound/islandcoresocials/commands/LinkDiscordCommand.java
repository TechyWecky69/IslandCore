package com.blockbound.islandcoresocials.commands;

import com.blockbound.islandcoresocials.IslandCoreSocials;
import com.blockbound.islandcoresocials.models.PlayerSocials;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class LinkDiscordCommand implements CommandExecutor {

    private final IslandCoreSocials plugin;

    public LinkDiscordCommand(IslandCoreSocials plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command,
                             String label, String[] args) {

        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        if (!player.hasPermission("islandcoresocials.link")) {
            player.sendMessage(plugin.msg("no-permission"));
            return true;
        }

        if (args.length != 1) {
            player.sendMessage(plugin.msg("link-usage"));
            return true;
        }

        PlayerSocials ps = plugin.getSocialDataManager()
                .get(player.getUniqueId(), player.getName());

        if (ps.hasDiscord()) {
            player.sendMessage(plugin.msg("link-fail-already"));
            return true;
        }

        String code = args[0].toUpperCase();

        // Call the bot API asynchronously so we don't block the main thread
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                String apiUrl = plugin.cfg("discord-api-url") + "/verify";
                String body = String.format(
                        "{\"code\":\"%s\",\"uuid\":\"%s\",\"name\":\"%s\"}",
                        code, player.getUniqueId(), player.getName()
                );

                HttpURLConnection conn = (HttpURLConnection) URI.create(apiUrl).toURL().openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                conn.setRequestProperty("Content-Type", "application/json");

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(body.getBytes(StandardCharsets.UTF_8));
                }

                int status = conn.getResponseCode();

                if (status == 200) {
                    // Parse discord_tag from response
                    Scanner sc = new Scanner(conn.getInputStream(), StandardCharsets.UTF_8);
                    String response = sc.useDelimiter("\\A").next();
                    sc.close();

                    String discordId = extractJson(response, "discord_id");
                    String discordTag = extractJson(response, "discord_tag");

                    // Back on the main thread: update & save
                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        ps.setDiscordId(discordId);
                        ps.setDiscordTag(discordTag);
                        plugin.getSocialDataManager().save(ps);
                        player.sendMessage(plugin.msg("link-success",
                                "{discord_tag}", discordTag));
                    });

                } else {
                    plugin.getServer().getScheduler().runTask(plugin, () ->
                            player.sendMessage(plugin.msg("link-fail-invalid")));
                }

            } catch (Exception e) {
                plugin.getLogger().warning("Link API error: " + e.getMessage());
                plugin.getServer().getScheduler().runTask(plugin, () ->
                        player.sendMessage(plugin.msg("api-error")));
            }
        });

        return true;
    }

    /** Minimal JSON field extractor — avoids adding a JSON library dependency. */
    private String extractJson(String json, String key) {
        String search = "\"" + key + "\":\"";
        int start = json.indexOf(search);
        if (start < 0) return null;
        start += search.length();
        int end = json.indexOf('"', start);
        return end < 0 ? null : json.substring(start, end);
    }
}
