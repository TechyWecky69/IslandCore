package com.blockbound.islandcoresocials.listeners;

import com.blockbound.islandcoresocials.IslandCoreSocials;
import com.blockbound.islandcoresocials.managers.ChatInputManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class ChatInputListener implements Listener {

    private final IslandCoreSocials plugin;

    public ChatInputListener(IslandCoreSocials plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        ChatInputManager mgr = plugin.getChatInputManager();

        if (!mgr.isPending(player.getUniqueId())) return;

        // Cancel the chat event so the message doesn't appear publicly
        event.setCancelled(true);

        String message = event.getMessage().trim();

        if (message.equalsIgnoreCase("cancel")) {
            mgr.cancel(player.getUniqueId());
            // Send back on main thread
            plugin.getServer().getScheduler().runTask(plugin, () ->
                    player.sendMessage(plugin.msg("social-set-cancel")));
            return;
        }

        ChatInputManager.PendingInput pending = mgr.consume(player.getUniqueId());
        if (pending == null) return;

        // Sanitise: only allow alphanumeric, dots, underscores, hyphens
        String sanitised = message.replaceAll("[^a-zA-Z0-9._\\-]", "");
        if (sanitised.isBlank()) {
            plugin.getServer().getScheduler().runTask(plugin, () ->
                    player.sendMessage(plugin.msg("social-set-cancel")));
            return;
        }

        // Callback runs on main thread
        String finalSanitised = sanitised;
        plugin.getServer().getScheduler().runTask(plugin, () ->
                pending.callback().accept(finalSanitised));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        // Clean up if they disconnect while we're waiting for input
        plugin.getChatInputManager().cancel(event.getPlayer().getUniqueId());
    }
}
