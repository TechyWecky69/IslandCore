package com.blockbound.islandcoresocials.managers;

import com.blockbound.islandcoresocials.IslandCoreSocials;
import com.blockbound.islandcoresocials.models.PlayerSocials;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Persists player social data to plugins/IslandCoreSocials/data/<uuid>.yml
 */
public class SocialDataManager {

    private final IslandCoreSocials plugin;
    private final File dataFolder;
    private final Map<UUID, PlayerSocials> cache = new HashMap<>();

    public SocialDataManager(IslandCoreSocials plugin) {
        this.plugin = plugin;
        this.dataFolder = new File(plugin.getDataFolder(), "data");
        if (!dataFolder.exists()) dataFolder.mkdirs();
    }

    // ── Public API ────────────────────────────────────────────────────────────

    public PlayerSocials get(UUID uuid, String playerName) {
        if (cache.containsKey(uuid)) {
            PlayerSocials ps = cache.get(uuid);
            ps.setPlayerName(playerName); // refresh display name
            return ps;
        }
        PlayerSocials ps = load(uuid, playerName);
        cache.put(uuid, ps);
        return ps;
    }

    /**
     * Look up by offline player name (case-insensitive linear scan).
     * Fine for a social command; if the server is very large consider an index file.
     */
    public PlayerSocials getByName(String name) {
        // Check cache first
        for (PlayerSocials ps : cache.values()) {
            if (ps.getPlayerName().equalsIgnoreCase(name)) return ps;
        }
        // Scan data files
        File[] files = dataFolder.listFiles((d, n) -> n.endsWith(".yml"));
        if (files == null) return null;
        for (File f : files) {
            YamlConfiguration cfg = YamlConfiguration.loadConfiguration(f);
            if (name.equalsIgnoreCase(cfg.getString("name"))) {
                UUID uuid = UUID.fromString(f.getName().replace(".yml", ""));
                PlayerSocials ps = fromConfig(uuid, cfg);
                cache.put(uuid, ps);
                return ps;
            }
        }
        return null;
    }

    public void save(PlayerSocials ps) {
        File file = new File(dataFolder, ps.getUuid() + ".yml");
        YamlConfiguration cfg = new YamlConfiguration();
        cfg.set("name", ps.getPlayerName());
        cfg.set("discord_id", ps.getDiscordId());
        cfg.set("discord_tag", ps.getDiscordTag());
        cfg.set("youtube", ps.getYoutube());
        cfg.set("twitch", ps.getTwitch());
        cfg.set("tiktok", ps.getTiktok());
        try {
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save socials for " + ps.getPlayerName() + ": " + e.getMessage());
        }
    }

    public void saveAll() {
        cache.values().forEach(this::save);
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private PlayerSocials load(UUID uuid, String playerName) {
        File file = new File(dataFolder, uuid + ".yml");
        if (!file.exists()) return new PlayerSocials(uuid, playerName);
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        return fromConfig(uuid, cfg);
    }

    private PlayerSocials fromConfig(UUID uuid, YamlConfiguration cfg) {
        PlayerSocials ps = new PlayerSocials(uuid, cfg.getString("name", "Unknown"));
        ps.setDiscordId(cfg.getString("discord_id"));
        ps.setDiscordTag(cfg.getString("discord_tag"));
        ps.setYoutube(cfg.getString("youtube"));
        ps.setTwitch(cfg.getString("twitch"));
        ps.setTiktok(cfg.getString("tiktok"));
        return ps;
    }
}
