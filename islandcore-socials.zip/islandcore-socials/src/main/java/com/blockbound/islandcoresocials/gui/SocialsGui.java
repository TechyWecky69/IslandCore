package com.blockbound.islandcoresocials.gui;

import com.blockbound.islandcoresocials.IslandCoreSocials;
import com.blockbound.islandcoresocials.models.PlayerSocials;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * A 27-slot (3-row) chest GUI showing a player's social links.
 *
 * Layout (0-based slot index):
 *
 *   [ 0][ 1][ 2][ 3][ 4][ 5][ 6][ 7][ 8]
 *   [ 9][10][11][12][13][14][15][16][17]
 *   [18][19][20][21][22][23][24][25][26]
 *
 *  Slot  2 → Player Head (info)
 *  Slot  6 → Discord
 *  Slot 11 → YouTube
 *  Slot 15 → Twitch
 *  Slot 20 → TikTok
 *  Rest   → decorative glass panes
 */
public class SocialsGui {

    // GUI slot constants
    public static final int SLOT_DISCORD = 11;
    public static final int SLOT_YOUTUBE = 13;
    public static final int SLOT_TWITCH  = 15;
    public static final int SLOT_TIKTOK  = 22;

    // NBT-like tag embedded in the inventory title so the listener can identify it
    public static final String GUI_TITLE_OWN     = ChatColor.DARK_GRAY + "✦ " + ChatColor.AQUA + "Your Socials";
    public static final String GUI_TITLE_VIEWING = ChatColor.DARK_GRAY + "✦ " + ChatColor.AQUA + "%s's Socials";

    private SocialsGui() {}

    public static void open(IslandCoreSocials plugin, Player viewer,
                            PlayerSocials target, boolean editable) {

        String title = editable
                ? GUI_TITLE_OWN
                : String.format(GUI_TITLE_VIEWING, target.getPlayerName());

        Inventory inv = Bukkit.createInventory(null, 27, title);

        // Fill with glass panes
        ItemStack pane = makeItem(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 27; i++) inv.setItem(i, pane);

        // Player head
        inv.setItem(4, makeHead(target));

        // Social items
        inv.setItem(SLOT_DISCORD, makeDiscord(target, editable));
        inv.setItem(SLOT_YOUTUBE, makeYoutube(target, editable));
        inv.setItem(SLOT_TWITCH,  makeTwitch(target, editable));
        inv.setItem(SLOT_TIKTOK,  makeTiktok(target, editable));

        viewer.openInventory(inv);
    }

    // ── Item builders ─────────────────────────────────────────────────────────

    private static ItemStack makeHead(PlayerSocials ps) {
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) skull.getItemMeta();
        if (meta != null) {
            meta.setOwnerProfile(
                    Bukkit.createPlayerProfile(ps.getUuid(), ps.getPlayerName()));
            meta.setDisplayName(ChatColor.GOLD + "" + ChatColor.BOLD + ps.getPlayerName());
            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.GRAY + "Social Profiles");
            meta.setLore(lore);
            skull.setItemMeta(meta);
        }
        return skull;
    }

    private static ItemStack makeDiscord(PlayerSocials ps, boolean editable) {
        List<String> lore = new ArrayList<>();
        if (ps.hasDiscord()) {
            lore.add(ChatColor.GRAY + "Tag: " + ChatColor.WHITE + ps.getDiscordTag());
            lore.add("");
            if (editable) lore.add(ChatColor.YELLOW + "Already linked via /link in Discord.");
        } else {
            lore.add(ChatColor.RED + "Not linked");
            lore.add("");
            if (editable) {
                lore.add(ChatColor.YELLOW + "Run " + ChatColor.WHITE + "/link"
                        + ChatColor.YELLOW + " in our Discord");
                lore.add(ChatColor.YELLOW + "then use the code in-game.");
            }
        }
        return makeItem(Material.BOOK,
                ChatColor.BLUE + "" + ChatColor.BOLD + "Discord",
                lore.toArray(new String[0]));
    }

    private static ItemStack makeYoutube(PlayerSocials ps, boolean editable) {
        List<String> lore = new ArrayList<>();
        if (ps.hasYoutube()) {
            lore.add(ChatColor.GRAY + "Channel: " + ChatColor.WHITE + ps.getYoutube());
            lore.add(ChatColor.GRAY + "youtube.com/@" + ps.getYoutube());
        } else {
            lore.add(ChatColor.RED + "Not set");
        }
        lore.add("");
        if (editable) lore.add(ChatColor.YELLOW + "Click to " + (ps.hasYoutube() ? "update" : "set") + " your username.");
        return makeItem(Material.RED_DYE,
                ChatColor.RED + "" + ChatColor.BOLD + "YouTube",
                lore.toArray(new String[0]));
    }

    private static ItemStack makeTwitch(PlayerSocials ps, boolean editable) {
        List<String> lore = new ArrayList<>();
        if (ps.hasTwitch()) {
            lore.add(ChatColor.GRAY + "Channel: " + ChatColor.WHITE + ps.getTwitch());
            lore.add(ChatColor.GRAY + "twitch.tv/" + ps.getTwitch());
        } else {
            lore.add(ChatColor.RED + "Not set");
        }
        lore.add("");
        if (editable) lore.add(ChatColor.YELLOW + "Click to " + (ps.hasTwitch() ? "update" : "set") + " your username.");
        return makeItem(Material.PURPLE_DYE,
                ChatColor.LIGHT_PURPLE + "" + ChatColor.BOLD + "Twitch",
                lore.toArray(new String[0]));
    }

    private static ItemStack makeTiktok(PlayerSocials ps, boolean editable) {
        List<String> lore = new ArrayList<>();
        if (ps.hasTiktok()) {
            lore.add(ChatColor.GRAY + "Username: " + ChatColor.WHITE + "@" + ps.getTiktok());
            lore.add(ChatColor.GRAY + "tiktok.com/@" + ps.getTiktok());
        } else {
            lore.add(ChatColor.RED + "Not set");
        }
        lore.add("");
        if (editable) lore.add(ChatColor.YELLOW + "Click to " + (ps.hasTiktok() ? "update" : "set") + " your username.");
        return makeItem(Material.BLACK_DYE,
                ChatColor.DARK_GRAY + "" + ChatColor.BOLD + "TikTok",
                lore.toArray(new String[0]));
    }

    // ── Generic item factory ──────────────────────────────────────────────────

    public static ItemStack makeItem(Material material, String name, String... lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            if (lore.length > 0) {
                meta.setLore(Arrays.asList(lore));
            }
            item.setItemMeta(meta);
        }
        return item;
    }

    /** Returns true if the given inventory was opened by this GUI. */
    public static boolean isOurGui(Inventory inv) {
        if (inv == null || inv.getHolder() != null) return false;
        String title = inv.getLocation() == null ? "" : "";
        // We check via view title in the listener instead
        return true;
    }
}
