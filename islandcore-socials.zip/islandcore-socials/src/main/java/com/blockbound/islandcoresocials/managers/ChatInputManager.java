package com.blockbound.islandcoresocials.managers;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * Tracks players who are waiting to type a social username in chat.
 * The chat listener cancels the event and routes the message here.
 */
public class ChatInputManager {

    public enum Platform {
        YOUTUBE, TWITCH, TIKTOK
    }

    public record PendingInput(Platform platform, Consumer<String> callback) {}

    private final Map<UUID, PendingInput> pending = new HashMap<>();

    public void expect(UUID uuid, Platform platform, Consumer<String> callback) {
        pending.put(uuid, new PendingInput(platform, callback));
    }

    public boolean isPending(UUID uuid) {
        return pending.containsKey(uuid);
    }

    public PendingInput consume(UUID uuid) {
        return pending.remove(uuid);
    }

    public void cancel(UUID uuid) {
        pending.remove(uuid);
    }
}
