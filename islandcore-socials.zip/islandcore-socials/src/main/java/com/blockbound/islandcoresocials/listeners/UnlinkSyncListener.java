package com.blockbound.islandcoresocials.listeners;

import com.blockbound.islandcoresocials.IslandCoreSocials;
import com.blockbound.islandcoresocials.models.PlayerSocials;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

/**
 * Syncs Discord unlinks that were triggered from the Discord bot side.
 *
 * On every player join (and via a repeating task for players already online),
 * we ask the bot's API whether this UUID has been queued for an unlink.
 * If so, we clear the stored Discord data and acknowledge so the bot removes
 * the UUID from the queue.
 */
public class UnlinkSyncListener implements Listener {

    private final IslandCoreSocials plugin;

    public UnlinkSyncListener(IslandCoreSocials plugin) {
        this.plugin = plugin;
        schedulePeriodicCheck();
    }

    // ── Event: check immediately when a player joins ──────────────────────────

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin,
                () -> checkAndSync(player));
    }

    // ── Periodic check for players who are already online ─────────────────────

    private void schedulePeriodicCheck() {
        // Check every 5 minutes (6000 ticks) so an unlink from Discord
        // is reflected in-game within 5 minutes even if the player is logged in.
        plugin.getServer().getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            for (Player player : plugin.getServer().getOnlinePlayers()) {
                checkAndSync(player);
            }
        }, 6000L, 6000L);
    }

    // ── Core sync logic (always called from an async thread) ─────────────────

    void checkAndSync(Player player) {
        String uuid = player.getUniqueId().toString();
        String apiBase = plugin.cfg("discord-api-url");

        try {
            // 1. Poll the queue
            HttpURLConnection get = (HttpURLConnection)
                    URI.create(apiBase + "/unlink-queue/" + uuid).toURL().openConnection();
            get.setRequestMethod("GET");
            get.setConnectTimeout(5000);
            get.setReadTimeout(5000);

            if (get.getResponseCode() != 200) return;

            Scanner sc = new Scanner(get.getInputStream(), StandardCharsets.UTF_8);
            String body = sc.useDelimiter("\\A").next();
            sc.close();

            if (!body.contains("\"queued\":true")) return;

            // 2. Clear Discord data on main thread, then acknowledge
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                PlayerSocials ps = plugin.getSocialDataManager()
                        .get(player.getUniqueId(), player.getName());
                ps.setDiscordId(null);
                ps.setDiscordTag(null);
                plugin.getSocialDataManager().save(ps);

                player.sendMessage(plugin.msg("unlink-discord-notify"));

                // 3. Acknowledge back to the bot (async again)
                plugin.getServer().getScheduler().runTaskAsynchronously(plugin,
                        () -> ackUnlink(apiBase, uuid));
            });

        } catch (Exception e) {
            plugin.getLogger().warning("Unlink sync check failed for "
                    + player.getName() + ": " + e.getMessage());
        }
    }

    private void ackUnlink(String apiBase, String uuid) {
        try {
            HttpURLConnection del = (HttpURLConnection)
                    URI.create(apiBase + "/unlink-queue/" + uuid).toURL().openConnection();
            del.setRequestMethod("DELETE");
            del.setConnectTimeout(5000);
            del.setReadTimeout(5000);
            del.getResponseCode(); // fire and forget
        } catch (Exception e) {
            plugin.getLogger().warning("Unlink ack failed for " + uuid + ": " + e.getMessage());
        }
    }
}
