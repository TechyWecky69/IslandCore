package com.blockbound.islandcoresocials.listeners;

import com.blockbound.islandcoresocials.IslandCoreSocials;
import com.blockbound.islandcoresocials.gui.SocialsGui;
import com.blockbound.islandcoresocials.managers.ChatInputManager;
import com.blockbound.islandcoresocials.models.PlayerSocials;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class GuiClickListener implements Listener {

    private final IslandCoreSocials plugin;

    public GuiClickListener(IslandCoreSocials plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        String title = event.getView().getTitle();

        // Only handle our GUI titles
        boolean isOwnGui = title.equals(SocialsGui.GUI_TITLE_OWN);
        boolean isViewGui = title.startsWith(
                ChatColor.DARK_GRAY + "✦ " + ChatColor.AQUA);

        if (!isOwnGui && !isViewGui) return;

        event.setCancelled(true); // always cancel — no item picking

        if (!isOwnGui) return; // read-only view, nothing to click

        int slot = event.getRawSlot();
        PlayerSocials ps = plugin.getSocialDataManager()
                .get(player.getUniqueId(), player.getName());

        switch (slot) {
            case SocialsGui.SLOT_DISCORD -> {
                // Discord linking is done via the Discord bot, not here
                player.closeInventory();
                player.sendMessage(plugin.msg("no-permission")
                        .replace("You don't have permission to do that.",
                                ChatColor.YELLOW + "To link Discord, run "
                                        + ChatColor.WHITE + "/link"
                                        + ChatColor.YELLOW + " in our Discord server, then use the code with "
                                        + ChatColor.WHITE + "/linkdiscord <code>"
                                        + ChatColor.YELLOW + " here."));
            }
            case SocialsGui.SLOT_YOUTUBE -> promptForSocial(player, ps, ChatInputManager.Platform.YOUTUBE);
            case SocialsGui.SLOT_TWITCH  -> promptForSocial(player, ps, ChatInputManager.Platform.TWITCH);
            case SocialsGui.SLOT_TIKTOK  -> promptForSocial(player, ps, ChatInputManager.Platform.TIKTOK);
            default -> { /* decorative slot — do nothing */ }
        }
    }

    private void promptForSocial(Player player, PlayerSocials ps, ChatInputManager.Platform platform) {
        player.closeInventory();
        String platformName = platformDisplayName(platform);
        player.sendMessage(plugin.msg("social-set-prompt",
                "{platform}", platformName));

        plugin.getChatInputManager().expect(player.getUniqueId(), platform, value -> {
            switch (platform) {
                case YOUTUBE -> ps.setYoutube(value);
                case TWITCH  -> ps.setTwitch(value);
                case TIKTOK  -> ps.setTiktok(value);
            }
            plugin.getSocialDataManager().save(ps);
            player.sendMessage(plugin.msg("social-set-success",
                    "{platform}", platformName,
                    "{value}", value));
        });
    }

    private String platformDisplayName(ChatInputManager.Platform platform) {
        return switch (platform) {
            case YOUTUBE -> "YouTube";
            case TWITCH  -> "Twitch";
            case TIKTOK  -> "TikTok";
        };
    }
}
