package com.blockbound.islandcoresocials.models;

import java.util.UUID;

/**
 * Holds all social media links for one player.
 */
public class PlayerSocials {

    private final UUID uuid;
    private String playerName;

    private String discordId;   // snowflake, set by the link API
    private String discordTag;  // e.g. Steve#0001, set by the link API
    private String youtube;
    private String twitch;
    private String tiktok;

    public PlayerSocials(UUID uuid, String playerName) {
        this.uuid = uuid;
        this.playerName = playerName;
    }

    // ── UUID / name ───────────────────────────────────────────────────────────

    public UUID getUuid() { return uuid; }

    public String getPlayerName() { return playerName; }
    public void setPlayerName(String playerName) { this.playerName = playerName; }

    // ── Discord ───────────────────────────────────────────────────────────────

    public String getDiscordId() { return discordId; }
    public void setDiscordId(String discordId) { this.discordId = discordId; }

    public String getDiscordTag() { return discordTag; }
    public void setDiscordTag(String discordTag) { this.discordTag = discordTag; }

    public boolean hasDiscord() { return discordId != null && !discordId.isBlank(); }

    // ── Other socials ─────────────────────────────────────────────────────────

    public String getYoutube() { return youtube; }
    public void setYoutube(String youtube) { this.youtube = youtube; }
    public boolean hasYoutube() { return youtube != null && !youtube.isBlank(); }

    public String getTwitch() { return twitch; }
    public void setTwitch(String twitch) { this.twitch = twitch; }
    public boolean hasTwitch() { return twitch != null && !twitch.isBlank(); }

    public String getTiktok() { return tiktok; }
    public void setTiktok(String tiktok) { this.tiktok = tiktok; }
    public boolean hasTiktok() { return tiktok != null && !tiktok.isBlank(); }
}
