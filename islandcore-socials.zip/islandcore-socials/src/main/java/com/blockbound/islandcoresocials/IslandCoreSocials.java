package com.blockbound.islandcoresocials;

import com.blockbound.islandcoresocials.commands.LinkDiscordCommand;
import com.blockbound.islandcoresocials.commands.SocialCommand;
import com.blockbound.islandcoresocials.listeners.ChatInputListener;
import com.blockbound.islandcoresocials.listeners.GuiClickListener;
import com.blockbound.islandcoresocials.listeners.UnlinkSyncListener;
import com.blockbound.islandcoresocials.managers.ChatInputManager;
import com.blockbound.islandcoresocials.managers.SocialDataManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class IslandCoreSocials extends JavaPlugin {

    private static IslandCoreSocials instance;

    private SocialDataManager socialDataManager;
    private ChatInputManager chatInputManager;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();

        // Managers
        socialDataManager = new SocialDataManager(this);
        chatInputManager = new ChatInputManager();

        // Commands
        getCommand("linkdiscord").setExecutor(new LinkDiscordCommand(this));
        getCommand("social").setExecutor(new SocialCommand(this));

        // Listeners
        getServer().getPluginManager().registerEvents(new GuiClickListener(this), this);
        getServer().getPluginManager().registerEvents(new ChatInputListener(this), this);
        getServer().getPluginManager().registerEvents(new UnlinkSyncListener(this), this);

        getLogger().info("IslandCore Socials enabled!");
    }

    @Override
    public void onDisable() {
        if (socialDataManager != null) {
            socialDataManager.saveAll();
        }
        getLogger().info("IslandCore Socials disabled.");
    }

    // ── Accessors ─────────────────────────────────────────────────────────────

    public static IslandCoreSocials getInstance() {
        return instance;
    }

    public SocialDataManager getSocialDataManager() {
        return socialDataManager;
    }

    public ChatInputManager getChatInputManager() {
        return chatInputManager;
    }

    public String cfg(String path) {
        return getConfig().getString(path, "");
    }

    /** Applies colour codes and the configured prefix. */
    public String msg(String key) {
        String prefix = org.bukkit.ChatColor.translateAlternateColorCodes('&', cfg("messages.prefix"));
        String raw = cfg("messages." + key);
        return prefix + org.bukkit.ChatColor.translateAlternateColorCodes('&', raw);
    }

    /** msg() with simple placeholder replacement. */
    public String msg(String key, Object... replacements) {
        String m = msg(key);
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            m = m.replace(String.valueOf(replacements[i]), String.valueOf(replacements[i + 1]));
        }
        return m;
    }
}
